"""
This file contains functions that can be called to create a schema for LOWCBF
subarray commands, then the schema can be used to check JSON input to the
command.
"""

from schema import Schema

from .._common import TMSchema
from .version import (  # lowcbf_scan_uri, # unused, all scan versions same
    lowcbf_assignresources_uri,
    lowcbf_configurescan_uri,
    lowcbf_releaseresources_uri,
)

# from . import validators


def get_lowcbf_assignresources_schema(version: str, strict: bool) -> Schema:
    """SKA LOWCBF Assign Resources schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    # if_strict = mk_if(strict)

    if version.startswith(lowcbf_assignresources_uri(0, 1)):
        return get_lowcbf_assignresources_v1(version, strict)
    else:
        # only v0.1 has non-empty argument, all others are empty, i.e. v2
        return get_lowcbf_assignresources_v2(version, strict)


def get_lowcbf_assignresources_v2(version: str, strict: bool) -> Schema:
    items = TMSchema.new("LOWCBF assign resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload.",
    )
    # AssignResources argument is empty for LowCBF
    items.add_field(
        "lowcbf", {}, description="LOWCBF resources (unused, empty)"
    )
    return items


def get_lowcbf_assignresources_v1(version: str, strict: bool) -> Schema:
    # Description of each individual resource
    lowcbf_resource_elems = TMSchema.new("LOWCBF resources", version, strict)
    lowcbf_resource_elems.add_field(
        "device", str, description="Name of FSP or P4 device"
    )
    lowcbf_resource_elems.add_field(
        "shared",
        bool,
        description="Whether device is shared with other subarrays",
    )
    lowcbf_resource_elems.add_opt_field(
        "fw_image", str, description="Name of firmware image to load on device"
    )
    lowcbf_resource_elems.add_opt_field(
        "fw_mode", str, description="Mode in which firmware runs"
    )

    # Description of array holding multiple resources
    lowcbf_resource_blk = TMSchema.new("LOWCBF resources", version, strict)
    lowcbf_resource_blk.add_field(
        "resources",
        [lowcbf_resource_elems],
        description="array of LOWCBF resources",
    )

    # Top level assign resources description, containing array
    items = TMSchema.new("LOWCBF assign resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload.",
    )
    items.add_field(
        "lowcbf", lowcbf_resource_blk, description="LOWCBF resources"
    )
    return items


def get_lowcbf_configurescan_schema(version: str, strict: bool) -> Schema:
    """SKA LOWCBF configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    # if_strict = mk_if(strict)

    if version.startswith(lowcbf_configurescan_uri(0, 1)):
        return get_lowcbf_configurescan_v1(version, strict)
    if version.startswith(lowcbf_configurescan_uri(0, 2)):
        return get_lowcbf_configurescan_v2(version, strict)


def get_all_stn_beams_descr(version: str, strict: bool) -> Schema:
    """Low.CBF station beams description schema"""
    stn_beam_descr = TMSchema.new("Subarray station beams", version, strict)
    stn_beam_descr.add_field("beam_id", int, description="station beam id")
    stn_beam_descr.add_field(
        "freq_ids",
        [
            int,
        ],
        description="list of station beam frequency ids",
    )
    if version.startswith(lowcbf_configurescan_uri(0, 1)):
        stn_beam_descr.add_field("boresight_dly_poly", str, description="URL")
    else:
        stn_beam_descr.add_field("delay_poly", str, description="URL")
    all_stn_beams_descr = TMSchema.new(
        "Subarray stations and station beams", version, strict
    )
    all_stn_beams_descr.add_field(
        "stns",
        [
            [int, int],  # ie [station_id, substation_id],
        ],
        description="",
    )
    all_stn_beams_descr.add_field(
        "stn_beams",
        [
            stn_beam_descr,
        ],
        description="",
    )
    return all_stn_beams_descr


def get_pst_dest(version: str, strict: bool) -> Schema:
    """Description of PST host destination - IP, port, channels sent"""
    pst_dest = TMSchema.new("PST beams description", version, strict)
    pst_dest.add_field("data_host", str, description="dotted ipv4 address")
    pst_dest.add_field("data_port", int, description="UDP port number")
    pst_dest.add_field("start_channel", int, description="first chan to host")
    pst_dest.add_field("num_channels", int, description="no. chans to host")

    return pst_dest


def get_pst_beam_descr_outer(version: str, strict: bool) -> Schema:
    """Low.CBF PST beam description schema"""
    pst_beam_descr = TMSchema.new("PST beams description", version, strict)
    pst_beam_descr.add_field(
        "stn_beam_id", int, description="Station beam ID for pst beamforming"
    )
    pst_beam_descr.add_field("pst_beam_id", int, description="PST beam ID")
    if version.startswith(lowcbf_configurescan_uri(0, 1)):
        pst_beam_descr.add_opt_field(
            "firmware", str, description="Firmware name"
        )
        pst_beam_descr.add_field(
            "offset_dly_poly", str, description="Delay polynomial source URI"
        )
        pst_beam_descr.add_field(
            "dest_ip",
            [
                str,
            ],
            description="Beam destination [ip_addr:port]",
        )
        pst_beam_descr.add_field(
            "dest_chans",
            [
                int,
            ],
            description="Number of fine chans to a destination",
        )
    else:
        pst_beam_descr.add_field(
            "delay_poly", str, description="Delay polynomial source URI"
        )
        pst_beam_descr.add_field(
            "destinations",
            [
                get_pst_dest(version, strict),
            ],
            description="PST server addrs",
        )

    pst_beam_descr.add_field(
        "jones", str, description="Jones matrix source URI"
    )
    pst_beam_descr.add_field(
        "stn_weights",
        [
            float,
        ],
        description="weights for each station",
    )
    pst_beam_descr.add_opt_field(
        "rfi_enable",
        [
            bool,
        ],
        description="Master enable for RFI flagging",
    )
    pst_beam_descr.add_opt_field(
        "rfi_static_chans",
        [
            int,
        ],
        description="Freqency IDs to be always flagged",
    )
    pst_beam_descr.add_opt_field(
        "rfi_dynamic_chans",
        [
            int,
        ],
        description="Frequency IDs to be dynamically flagged",
    )
    pst_beam_descr.add_opt_field(
        "rfi_weighted", float, description="Parameter for dynamic flagging"
    )

    pst_beam_descr_outer = TMSchema.new("outer", version, strict)
    pst_beam_descr_outer.add_field(
        "beams",
        [
            pst_beam_descr,
        ],
        description="inner",
    )
    if not version.startswith(lowcbf_configurescan_uri(0, 1)):
        pst_beam_descr_outer.add_field(
            "fsp",
            get_fsp_descr(version, strict),
            description="FSPs used by PST",
        )
    return pst_beam_descr_outer


def get_fsp_descr(version: str, strict: bool) -> Schema:
    """Low.CBF FSP description schema"""
    fsp_descr = TMSchema.new("FSP", version, strict)
    fsp_descr.add_field("function_mode", str, description="Function mode")
    fsp_descr.add_field(
        "fsp_ids",
        [
            int,
        ],
        description="List of IDs (integer)",
    )

    return fsp_descr


def get_vis_stn_beams(version: str, strict: bool) -> Schema:
    """Low.CBF schema for station beams from which to calculate visibilities"""
    vis_stn_beams = TMSchema.new("Station beams to correlate", version, strict)
    vis_stn_beams.add_field("stn_beam_id", int, description="Station Beam ID")
    vis_stn_beams.add_field(
        "integration_ms", int, description="milliseconds integration"
    )
    vis_stn_beams.add_field(
        "host",
        [
            [int, str],
        ],
        description="SDP channel & IP Address",
    )
    vis_stn_beams.add_field(
        "port",
        [
            [int, int, int],
        ],
        description="SDP chan & UDP port, stride",
    )
    vis_stn_beams.add_opt_field(
        "mac",
        [
            [int, str],
        ],
        description="SDP channel & server MAC",
    )
    return vis_stn_beams


def get_vis_descr_outer(version: str, strict: bool) -> Schema:
    """Low.CBF visibilities schema"""
    vis_outer = TMSchema.new("Visibilities description", version, strict)
    vis_outer.add_field(
        "fsp",
        get_fsp_descr(version, strict),
        description="FSPs used for correlation",
    )
    vis_outer.add_field(
        "stn_beams",
        [
            get_vis_stn_beams(version, strict),
        ],
        description="SDP visibility destinations",
    )
    return vis_outer


def get_lowcbf_configurescan_v2(version: str, strict: bool) -> Schema:
    """SKA LOWCBF configuration schema version 2

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    lowcbf = TMSchema.new(
        "LOWCBF subarray configurescan description", version, strict
    )
    lowcbf.add_field(
        "stations",
        get_all_stn_beams_descr(version, strict),
        description="Subarray Stations and station beam input descriptions",
    )
    lowcbf.add_opt_field(
        "timing_beams",
        get_pst_beam_descr_outer(version, strict),
        description="PST beam outputs descriptions",
    )
    lowcbf.add_opt_field(
        "search_beams",
        str,  # contents TBD
        description="PSS beam outputs descriptions",
    )
    lowcbf.add_opt_field(
        "vis",
        get_vis_descr_outer(version, strict),
        description="Visibility output descriptions",
    )
    lowcbf.add_opt_field(
        "zooms",
        str,  # contents TBD
        description="Zoom visibility output descriptions",
    )

    items = TMSchema.new("LOWCBF configurescan", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload..",
    )
    items.add_field(
        "lowcbf", lowcbf, description="LOWCBF configuration for scan"
    )
    return items


def get_lowcbf_configurescan_v1(version: str, strict: bool) -> Schema:
    """SKA LOWCBF configuration schema version 1

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    lowcbf = TMSchema.new(
        "LOWCBF subarray configurescan description", version, strict
    )
    lowcbf.add_field(
        "stations",
        get_all_stn_beams_descr(version, strict),
        description="Subarray Stations and station beam input descriptions",
    )
    lowcbf.add_opt_field(
        "timing_beams",
        get_pst_beam_descr_outer(version, strict),
        description="PST beam outputs descriptions",
    )
    lowcbf.add_opt_field(
        "search_beams",
        str,  # contents TBD
        description="PSS beam outputs descriptions",
    )
    lowcbf.add_opt_field(
        "visibilities",
        str,  # contents TBD
        description="Visibility output descriptions",
    )
    lowcbf.add_opt_field(
        "zooms",
        str,  # contents TBD
        description="Zoom visibility output descriptions",
    )

    items = TMSchema.new("LOWCBF configurescan", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload..",
    )
    items.add_field(
        "lowcbf", lowcbf, description="LOWCBF configuration for scan"
    )
    return items


def get_lowcbf_releaseresources_schema(version: str, strict: bool) -> Schema:
    """SKA LOWCBF release resources schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    # if_strict = mk_if(strict)

    if version.startswith(lowcbf_releaseresources_uri(0, 1)):
        return get_lowcbf_releaseresources_v1(version, strict)
    else:
        # only v0.1 has non-empty argument, all others are empty, i.e. v2
        return get_lowcbf_releaseresources_v2(version, strict)


def get_lowcbf_releaseresources_v2(version: str, strict: bool) -> Schema:
    items = TMSchema.new("LOWCBF release resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload..",
    )
    items.add_field(
        "lowcbf",
        {},
        description="LOWCBF Release resources (unused, empty)",
    )
    return items


def get_lowcbf_releaseresources_v1(version: str, strict: bool) -> Schema:
    # Description of each individual resource
    lowcbf_resource_elems = TMSchema.new("LOWCBF resources", version, strict)
    lowcbf_resource_elems.add_field(
        "device", str, description="Name of FSP or P4 device"
    )

    # Description of array holding multiple resources
    lowcbf_resource_blk = TMSchema.new("LOWCBF resources", version, strict)
    lowcbf_resource_blk.add_field(
        "resources",
        [
            lowcbf_resource_elems,
        ],
        description="array of LOWCBF resources",
    )

    items = TMSchema.new("LOWCBF release resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload..",
    )
    items.add_field(
        "lowcbf",
        lowcbf_resource_blk,
        description="LOWCBF Release resources schema",
    )
    return items


def get_lowcbf_scan_schema(version: str, strict: bool) -> Schema:
    """SKA LOWCBF scan schema

    Currently same schema for any version of interface

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    # if_strict = mk_if(strict)

    scan_descr = TMSchema.new("LOWCBF scan description", version, strict)
    scan_descr.add_field("scan_id", int, description="Scan ID")

    items = TMSchema.new("LOWCBF scan description", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema for this command's JSON payload..",
    )
    items.add_field("lowcbf", scan_descr, description="LOWCBF scan arguments")
    return items

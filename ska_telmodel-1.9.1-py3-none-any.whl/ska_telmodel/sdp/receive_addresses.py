"""Defines receive addresses schema."""
from inspect import cleandoc

from schema import Literal, Optional, Schema

from ska_telmodel._common import TMSchema, get_channel_map_schema

from .common import get_beam_function_pattern
from .schema import get_sdp_recvaddrs_schema, get_type_name_schema
from .version import VERSION_TYPE

DESCRIPTION = cleandoc(
    """
    Provides information about receive node addresses to use
    for ingesting measurement data to SDP (such as visibility
    SPEAD streams).

    Receive addresses consists of a map of scan type to a
    receive address map. This address map must be set once the
    SDP subarray finishes the transition following
    ``AssignResources`` (i.e. IDLE following the current
    state of ADR-8). TMC will then check SDP's subarray
    ``receiveAddresses`` attribute when preparing to configure
    elements for a certain scan type.

    Note that this has been changed to use the more compact
    channel map format defined in ADR-4. The general idea
    still applies: A map is given as a list, each entry of the
    format ``[start_channel, value]``. The first entry specifies
    the first channel ID the map applies to. So in the
    example, the host for channels 0-399 is "192.168.0.1",
    while the host for channels 400-799 is "192.168.0.2" and
    so forth.

    A minor extension applies to the port map, where every map
    entry is given as ``[start_channel, start_value,
    increment]``. The true value for a channel is given from
    the applicable map entry by::

        value = start_value + (channel - start_channel) * increment

    So in the example, channels 0-399 should be sent to host
    "192.168.0.1" at ports 9000-9399, and channels 400-799 to
    host "192.168.0.2" at ports 9000-9399. If we had said
    ``"port": [[0, 9000, 0]`` all packets would be sent to the
    same port. Equally ``"port": [[0, 9000, 2]`` would indicate
    spacing the ports out by steps of 2.

    Unused channel IDs should be ignored. This especially
    applies to unused gaps and channel ID strides possibly
    resulting from averaging at CBF. This means that with an
    averaging degree of 2 (see channelAveragingMap in ADR-4),
    only every second channel ID would be used in the example
    above.
    """
)


# Pre-ADR-10 schema
def get_sdp_recvaddrs_v1(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP receive addresses",
        version,
        strict,
        schema={
            Optional("interface"): str,
            "scanId": int,
            "totalChannels": int,
            "receiveAddresses": [
                {
                    "phaseBinId": int,
                    "fspId": int,
                    "hosts": [
                        {
                            "host": str,
                            "channels": [
                                {
                                    "portOffset": int,
                                    "startChannel": int,
                                    "numChannels": int,
                                }
                            ],
                        }
                    ],
                }
            ],
        },
    )


def get_host() -> Literal:
    return Literal(
        "host",
        description=cleandoc(
            """
            Destination host names (as channel map)

            Note that these are not currently guaranteed to be IP
            addresses, so a DNS resolution  might be required.
            """
        ),
    )


def get_port() -> Literal:
    return Literal(
        "port",
        description="Destination ports (as channel map)",
    )


def get_receive_map(strict: bool) -> dict:
    return {
        get_host(): get_channel_map_schema(str, 0, strict),
        Optional(
            Literal(
                "mac",
                description=cleandoc(
                    """
                    Destination MAC addresses (as channel map)

                    Likely not going to be used, downstream systems should use
                    ARP to determine the MAC address using ``host`` instead.
                    See ADR-36
                    """
                ),
            )
        ): get_channel_map_schema(str, 0, strict),
        Optional(get_port()): get_channel_map_schema(int, 0, strict),
    }


def get_sdp_recvaddrs_v2(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP receive addresses map",
        version,
        strict,
        schema={
            Optional("interface"): str,
            get_type_name_schema(version, strict, "scan"): get_receive_map(
                strict
            ),
        },
        description=DESCRIPTION,
    )


def get_beam(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Beam receive addresses",
        version,
        strict,
        schema={
            get_host(): get_channel_map_schema(str, 0, strict),
            get_port(): get_channel_map_schema(int, 0, strict),
        },
        description="Receive addresses associated with a certain beam",
        as_reference=True,
    )
    schema.add_opt_field(
        "mac",
        get_channel_map_schema(str, 0, strict),
        description=cleandoc(
            """
            Destination MAC addresses (as channel map)

            Likely not going to be used, downstream systems should use
            ARP to determine the MAC address using ``host`` instead. See ADR-36
            """
        ),
    )
    schema.add_field(
        "function",
        get_beam_function_pattern(strict),
        description=cleandoc(
            """
            Type of beam configured. Beam identity is then given by the
            appropriate `beam_id` field.
            """
        ),
    )
    schema.add_opt_field(
        "visibility_beam_id",
        int,
        description=cleandoc(
            """
            Identifies visibility beam

            Might get omitted for SKA Mid, as it is assumed to have
            only one visibility beam.
            """
        ),
    )
    schema.add_opt_field(
        "search_beam_id", int, description="Identifies pulsar search beam"
    )
    schema.add_opt_field(
        "timing_beam_id", int, description="Identifies pulsar timing beam"
    )
    schema.add_opt_field(
        "vlbi_beam_id",
        int,
        description="Identifies very long baseline interferometry beam",
    )
    schema.add_opt_field(
        "search_window_id",
        int,
        description="Identifies search window for transient data capture",
    )
    schema.add_opt_field(
        "delay_cal",
        get_channel_map_schema(str, 0, strict),
        description=cleandoc(
            """
            Tango FQDNs serving gain/
            delay calibration solutions for TMC
            """
        ),
    ),
    schema.add_opt_field(
        "jones_cal",
        get_channel_map_schema(str, 0, strict),
        description=cleandoc(
            """
            Tango FQDNs serving real-time calibration
            Jones matrices for CBF
            """
        ),
    )
    return schema


def get_beams(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Beams",
        version,
        strict,
        description="Set of beams",
    )
    schema.add_field(
        get_type_name_schema(version, strict, "beam"),
        get_beam(version, strict),
        description="Beam",
    )
    return schema


def get_sdp_recvaddrs_v3(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP receive addresses map",
        version,
        strict,
        schema={
            Optional("interface"): str,
            get_type_name_schema(version, strict, "scan"): get_beams(
                version, strict
            ),
        },
        description=DESCRIPTION,
    )


get_sdp_recvaddrs_schema.register_all(("0.0", "0.1"), get_sdp_recvaddrs_v1)
get_sdp_recvaddrs_schema.register_all(("0.2", "0.3"), get_sdp_recvaddrs_v2)
get_sdp_recvaddrs_schema.register("0.4", get_sdp_recvaddrs_v3)

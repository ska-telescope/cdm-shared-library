"""Define processing blocks schemas."""
from inspect import cleandoc

from schema import Optional, Or, Schema

from ska_telmodel._common import TMSchema

from .schema import (
    get_pb_dependency_schema,
    get_pb_name_schema,
    get_processing_block_schema,
    get_sbi_name_schema,
)


def get_pb_dependency_v1(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "Processing block dependency",
        version,
        strict,
        schema={
            "pb_id": get_pb_name_schema(version, strict),
            "type": [str],
        },
    )


def get_pb_dependency_v2(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "Processing block dependency",
        version,
        strict,
        schema={
            "pb_id": get_pb_name_schema(version, strict),
            "kind": [str],
        },
    )


def get_processing_block_v1(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "Processing block",
        version,
        strict,
        schema={
            "id": get_pb_name_schema(version, strict),
            "workflow": {"type": str, "id": str, "version": str},
            Optional("parameters"): dict,
            Optional("dependencies"): [
                get_pb_dependency_schema(version, strict)
            ],
        },
        as_reference=True,
    )


def get_script_schema(name: str, version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        name,
        version,
        strict,
        description=cleandoc(
            """
            Data object within the Processing Block which describes
            the workflow that should be executed along with its
            configuration, to be assigned to a subarray.
            This is used to select the processing script from a set
            of scripts that have been validated to run on the SDP.
            """
        ),
    )
    schema.add_field(
        "kind",
        str,
        check_strict=Or("realtime", "batch"),
        description="The kind of processing script (realtime or batch)",
    )
    schema.add_field(
        "name", str, description="The name of the processing script"
    )
    schema.add_field(
        "version",
        str,
        description="Version of the processing script. "
        "Uses semantic versioning.",
    )
    return schema


def get_processing_block_v2(
    version: str, strict: bool, script_name="workflow"
) -> TMSchema:
    schema = TMSchema.new(
        "Processing block",
        version,
        strict,
        as_reference=True,
        description=cleandoc(
            """
            A Processing Block is an atomic unit of data processing
            for the purpose of SDP's internal scheduler. Each PB
            references a processing script and together with the
            associated execution block provides all parameters
            necessary to carry out scheduling - both on TM's side for
            observation planning and on SDP's side - as well as enable
            processing to locate all required inputs once it is in
            progress.

            PBs are used for both real-time and deferred, batch,
            processing. An execution block will often contain many
            Processing Blocks, for example for ingest,
            self-calibration and Data Product preparation.
            """
        ),
    )

    schema.add_field(
        "pb_id",
        get_pb_name_schema(version, strict),
        description="Unique identifier for this processing block.",
    )

    schema.add_field(
        script_name,
        get_script_schema(script_name, version, strict),
        description=cleandoc(
            """
            Specification of the workflow to be executed along with
            configuration parameters for the workflow.
            """
        ),
    )
    schema.add_opt_field(
        "parameters",
        dict,
        description=cleandoc(
            """
            Configuration parameters needed to execute the workflow. As these
            parameters will be workflow specific, this is left as an
            object to be specified by the workflow definition.
            """
        ),
    )
    schema.add_opt_field(
        "dependencies",
        [get_pb_dependency_schema(version, strict)],
        description=cleandoc(
            """
            A dependency between processing blocks means that one
            processing block requires something from the other
            processing block to run - typically an intermediate Data
            Product.  This generally means that

            1. The dependent processing block might only be able
               to start once the dependency has been fulfilled

            2. Data associated with the dependency must be kept alive
               until the dependent processing block is finished.

            As processing blocks might have many different outputs,
            the dependency "kind" can be used to specify how this
            dependency is meant to be interpreted
            (e.g. "visibilities", "calibration"...)
            """
        ),
    )
    return schema


def get_processing_block_v3(version: str, strict: bool) -> Schema:
    schema = get_processing_block_v2(version, strict, script_name="script")
    schema.add_opt_field(
        "sbi_ids",
        [get_sbi_name_schema(version, strict)],
        description=cleandoc(
            """
            Scheduling block instances that the processing block
            belongs to.
            """
        ),
    )
    return schema


get_processing_block_schema.register_all(
    ("0.0", "0.1", "0.2"), get_processing_block_v1
)
get_processing_block_schema.register("0.3", get_processing_block_v2)
get_processing_block_schema.register("0.4", get_processing_block_v3)
get_pb_dependency_schema.register_all(
    ("0.0", "0.1", "0.2"), get_pb_dependency_v1
)
get_pb_dependency_schema.register_all(("0.3", "0.4"), get_pb_dependency_v2)

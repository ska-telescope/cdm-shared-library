"""
Used for checking SDP strings for conformance.
"""

from typing import Type, Union

from schema import Schema

from .._common import get_unique_id_schema
from .version import (
    SDP_ASSIGNRES_PREFIX,
    SDP_CONFIGURE_PREFIX,
    SDP_RECVADDRS_PREFIX,
    SDP_RELEASERES_PREFIX,
    SDP_SCAN_PREFIX,
    SchemaFactory,
)


def get_sbi_name_schema(version: str, strict: bool) -> Schema:
    return get_unique_id_schema(strict, r"sbi")


def get_txn_name_schema(version: str, strict: bool) -> Schema:
    return get_unique_id_schema(strict, r"txn")


def get_eb_name_schema(version: str, strict: bool) -> Schema:
    return get_unique_id_schema(strict, r"eb")


def get_pb_name_schema(version: str, strict: bool) -> Schema:
    return get_unique_id_schema(strict, r"pb")


def get_type_name_schema(
    version: str, strict: bool, type_name: str
) -> Union[str, Type[str]]:
    # A bit of a hack - this is used in a key, and JSON schemas want a
    # string there if they are to generate meaningful documentation.
    if strict == "json-schema":  # pragma: no cover
        return f"(any {type_name} type)"
    return str


# Define the functions that are redirected according to version.
# Note that the SchemaFactory instances are callable.
get_scan_channels_schema = SchemaFactory(
    allowed_prefixes=[SDP_ASSIGNRES_PREFIX, SDP_CONFIGURE_PREFIX]
)
get_scan_type_schema = SchemaFactory(
    allowed_prefixes=[SDP_ASSIGNRES_PREFIX, SDP_CONFIGURE_PREFIX]
)
get_processing_block_schema = SchemaFactory(
    allowed_prefixes=SDP_ASSIGNRES_PREFIX
)
get_pb_dependency_schema = SchemaFactory(allowed_prefixes=SDP_ASSIGNRES_PREFIX)
get_execution_block_schema = SchemaFactory(
    allowed_prefixes=SDP_ASSIGNRES_PREFIX
)
get_sdp_recvaddrs_schema = SchemaFactory(
    prefix=SDP_RECVADDRS_PREFIX,
    allowed_prefixes=SDP_RECVADDRS_PREFIX,
)
get_sdp_scan_schema = SchemaFactory(
    prefix=SDP_SCAN_PREFIX,
    allowed_prefixes=SDP_SCAN_PREFIX,
)
get_sdp_configure_schema = SchemaFactory(
    prefix=SDP_CONFIGURE_PREFIX,
    allowed_prefixes=SDP_CONFIGURE_PREFIX,
)
get_sdp_assignres_schema = SchemaFactory(
    prefix=SDP_ASSIGNRES_PREFIX,
    allowed_prefixes=SDP_ASSIGNRES_PREFIX,
)
get_sdp_releaseres_schema = SchemaFactory(
    prefix=SDP_RELEASERES_PREFIX,
    allowed_prefixes=SDP_RELEASERES_PREFIX,
)

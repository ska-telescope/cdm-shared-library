"""Define processing blocks schemas."""
from inspect import cleandoc

from schema import Literal, Optional, Schema

from ska_telmodel._common import TMSchema
from ska_telmodel.sdp.schema import (
    get_eb_name_schema,
    get_execution_block_schema,
    get_scan_channels_schema,
    get_scan_type_schema,
)

from .common import get_beam_function_pattern


def get_beam(version: str, strict: bool) -> Schema:
    # Can/should this be tied down more?
    schema = TMSchema.new(
        "Beam",
        version,
        strict,
        schema={},
        description=cleandoc(
            """
            Beam parameters for the purpose of the Science Data
            Processor.
            """
        ),
        as_reference=True,
    )
    schema.add_field(
        "beam_id",
        str,
        description="Name to identify the beam within the SDP configuration.",
    )
    schema.add_field(
        "function",
        get_beam_function_pattern(strict),
        description=cleandoc(
            """
            Identifies the type and origin of the generated beam data.  This
            corresponds to a certain kind of calibration or receive
            functionality SDP is meant to provide for it.

            Possible options:

            * `visibilities`: Correlated voltages from CBF used for
              calibration and imaging
            * `pulsar search`: SDP provides calibrations for tied-array
              beam as well as post-processes and delivers pulsar search
              data products
            * `pulsar timing`: SDP provides calibrations for tied-array
              beam as well as post-processes and delivers pulsar timing
              data products
            * `vlbi`: SDP provides calibrations for tied-array
              beam
            * `transient buffer`: SDP receives and delivers transient
              buffer data dumps
            """
        ),
    )
    for beam_type in ("search", "timing", "vlbi"):
        schema.add_opt_field(f"{beam_type}_beam_id", int)
    return schema


def get_polarisation(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "polarisation",
        version,
        strict,
        schema={"polarisations_id": str, "corr_type": [str]},
        description="Polarisation definition.",
    )


def get_phase_dir(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "phase_dir",
        version,
        strict,
        schema={
            "ra": [Schema(lambda x: 0.0 <= x < 360.0)],
            "dec": [Schema(lambda x: -90.0 <= x <= 90.0)],
            "reference_time": str,
            "reference_frame": "ICRF3",
        },
        description="Phase direction",
    )


def get_field(version: str, strict: bool) -> Schema:
    return TMSchema.new(
        "fields",
        version,
        strict,
        schema={
            "field_id": str,
            "phase_dir": get_phase_dir(version, strict),
            Optional("pointing_fqdn"): str,
        },
        description="Fields / Targets",
    )


def get_execution_block_v1(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Execution block",
        version,
        strict,
        schema={
            "eb_id": get_eb_name_schema(version, strict),
            "max_length": float,
            Literal(
                "context",
                description="Free-form information from OET, see ADR-54",
            ): Schema(
                object
            ),  # doesn't work without explicit schema object
        },
        as_reference=True,
    )
    schema.add_field(
        "beams", [get_beam(version, strict)], description="Beam parameters"
    )
    schema.add_field(
        "scan_types",
        [get_scan_type_schema(version, strict)],
        description=cleandoc(
            """
            Scan types. Associates scans with per-beam
            fields & channel configurations
            """
        ),
    ),
    schema.add_field(
        "channels",
        [get_scan_channels_schema(version, strict)],
        description="Channels",
    )
    schema.add_field(
        "polarisations",
        [get_polarisation(version, strict)],
        description="Polarisation definitions",
    )
    schema.add_field(
        "fields", [get_field(version, strict)], description="Fields / targets"
    )
    return schema


get_execution_block_schema.register("0.4", get_execution_block_v1)

# Importing these populates the schema factories.
import ska_telmodel.sdp.commands  # noqa: F401
import ska_telmodel.sdp.execution_blocks  # noqa: F401
import ska_telmodel.sdp.processing_blocks  # noqa: F401
import ska_telmodel.sdp.receive_addresses  # noqa: F401
import ska_telmodel.sdp.scans  # noqa: F401

from .examples import (
    get_sdp_assignres_example,
    get_sdp_configure_example,
    get_sdp_recvaddrs_example,
    get_sdp_releaseres_example,
    get_sdp_scan_example,
)
from .schema import (
    get_sdp_assignres_schema,
    get_sdp_configure_schema,
    get_sdp_recvaddrs_schema,
    get_sdp_releaseres_schema,
    get_sdp_scan_schema,
)
from .version import (
    SDP_ASSIGNRES_PREFIX,
    SDP_CONFIGURE_PREFIX,
    SDP_RECVADDRS_PREFIX,
    SDP_RELEASERES_PREFIX,
    SDP_SCAN_PREFIX,
)

__all__ = [
    "get_sdp_assignres_example",
    "get_sdp_releaseres_example",
    "get_sdp_configure_example",
    "get_sdp_recvaddrs_example",
    "get_sdp_scan_example",
    "get_sdp_assignres_schema",
    "get_sdp_releaseres_schema",
    "get_sdp_configure_schema",
    "get_sdp_recvaddrs_schema",
    "get_sdp_scan_schema",
    "SDP_ASSIGNRES_PREFIX",
    "SDP_RELEASERES_PREFIX",
    "SDP_CONFIGURE_PREFIX",
    "SDP_RECVADDRS_PREFIX",
    "SDP_SCAN_PREFIX",
]

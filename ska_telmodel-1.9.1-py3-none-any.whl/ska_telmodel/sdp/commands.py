"""Define schemas for SDP commands."""
from inspect import cleandoc

from schema import Literal, Optional, Schema

from .._common import TMSchema
from .common import get_receptor_schema
from .schema import (
    get_eb_name_schema,
    get_execution_block_schema,
    get_processing_block_schema,
    get_sbi_name_schema,
    get_scan_type_schema,
    get_sdp_assignres_schema,
    get_sdp_configure_schema,
    get_sdp_releaseres_schema,
    get_sdp_scan_schema,
    get_txn_name_schema,
)
from .version import VERSION_TYPE


def get_sdp_scan_v1(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP scan",
        version,
        strict,
        schema={
            Optional("interface"): str,
            "id": int,
        },
    )


def get_sdp_scan_v2(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP scan",
        version,
        strict,
        schema={
            Optional("interface"): str,
            Optional("transaction_id"): get_txn_name_schema(version, strict),
            Literal("scan_id", description="ID associated with new scan"): int,
        },
        description="Indicates to SDP that a new scan is about to start",
    )


def get_sdp_configure_v1(version: VERSION_TYPE, strict: bool) -> Schema:
    return TMSchema.new(
        "SDP configure",
        version,
        strict,
        schema={
            Optional("interface"): str,
            "scan_type": str,
            Optional("new_scan_types"): [
                get_scan_type_schema(version, strict)
            ],
        },
    )


def get_sdp_configure_v2(version: VERSION_TYPE, strict: bool) -> Schema:
    schema = TMSchema.new(
        "SDP configure",
        version,
        strict,
        description=cleandoc(
            """
            Configures an SDP subarray for a number of scans of a certain
            previously-assigned type. See resource assignment.
            """
        ),
    )
    schema.add_opt_field("interface", str)
    schema.add_opt_field(
        "transaction_id", get_txn_name_schema(version, strict)
    )
    schema.add_field("scan_type", str)
    schema.add_opt_field(
        "new_scan_types", [get_scan_type_schema(version, strict)]
    )
    return schema


def get_external_resources_schema(
    version: VERSION_TYPE, strict: bool
) -> Schema:
    schema = TMSchema.new(
        "SDP external resources", version, strict, ignore_extra_keys=True
    )
    schema.add_opt_field("receptors", [get_receptor_schema(strict)])
    return schema


def get_sdp_assignres_v1(version: VERSION_TYPE, strict: bool) -> Schema:
    schema = TMSchema.new(
        "SDP assign resources",
        version,
        strict,
        schema={
            Optional("interface"): str,
            "id": get_sbi_name_schema(version, strict),
            Optional("max_length"): float,
            Literal(
                "scan_types",
                description="Scan types to be supported on subarray",
            ): [get_scan_type_schema(version, strict)],
            "processing_blocks": [
                get_processing_block_schema(version, strict)
            ],
        },
    )
    return schema


def _assign_res_common(version: VERSION_TYPE, strict: bool) -> TMSchema:
    schema = TMSchema.new(
        "SDP assign resources",
        version,
        strict,
        description=cleandoc(
            """
            Used for assigning resources to an SDP subarray.

            As concrete resource usage for the SDP depend strongly on
            the underlying processing script, this fully parameterises all
            processing blocks to be executed. This especially means
            that in contrast to most other sub-systems, SDP processing
            deployments might persist across scans (and scan
            configuration) boundaries.
            """
        ),
    )
    schema.add_opt_field("interface", str)
    schema.add_opt_field(
        "transaction_id", get_txn_name_schema(version, strict)
    )
    return schema


def get_sdp_assignres_v2(version: VERSION_TYPE, strict: bool) -> TMSchema:
    schema = _assign_res_common(version, strict)

    schema.add_field(
        "eb_id",
        get_eb_name_schema(version, strict),
        description="Execution block ID to associate with processing",
    )
    schema.add_opt_field(
        "max_length",
        float,
        description=cleandoc(
            """
            Hint about the maximum observation length to support by
            the SDP. Used for ensuring that enough buffer capacity is
            available to capture measurements. Resources assignment
            might fail if we do not have enough space to guarantee
            that all data could be captured.
            """
        ),
    )
    schema.add_field(
        "scan_types",
        [get_scan_type_schema(version, strict)],
        description="Scan types to be supported on subarray",
    )
    schema.add_field(
        "processing_blocks", [get_processing_block_schema(version, strict)]
    )
    return schema


def get_sdp_assignres_v3(version: VERSION_TYPE, strict: bool) -> Schema:
    schema = _assign_res_common(version, strict)
    schema.add_opt_field(
        "execution_block",
        get_execution_block_schema(version, strict),
        description="Execution block",
    )
    schema.add_opt_field(
        "resources",
        get_external_resources_schema(version, strict),
        description="External resources",
    )
    schema.add_opt_field(
        "processing_blocks",
        [get_processing_block_schema(version, strict)],
        description="Processing blocks",
    )
    return schema


def get_sdp_releaseres_v1(version: VERSION_TYPE, strict: bool) -> Schema:
    schema = TMSchema.new(
        "SDP release resources",
        version,
        strict,
        description="Used for releasing resources for an SDP subarray.",
    )
    schema.add_opt_field("interface", str)
    schema.add_opt_field(
        "transaction_id", get_txn_name_schema(version, strict)
    )
    schema.add_field(
        "resources", get_external_resources_schema(version, strict)
    )
    return schema


get_sdp_scan_schema.register_all(("0.0", "0.1", "0.2"), get_sdp_scan_v1)
get_sdp_scan_schema.register_all(("0.3", "0.4"), get_sdp_scan_v2)
get_sdp_configure_schema.register_all(
    ("0.0", "0.1", "0.2"), get_sdp_configure_v1
)
get_sdp_configure_schema.register_all(("0.3", "0.4"), get_sdp_configure_v2)
get_sdp_assignres_schema.register_all(
    ("0.0", "0.1", "0.2"), get_sdp_assignres_v1
)
get_sdp_assignres_schema.register("0.3", get_sdp_assignres_v2)
get_sdp_assignres_schema.register("0.4", get_sdp_assignres_v3)
get_sdp_releaseres_schema.register("0.4", get_sdp_releaseres_v1)

"""Defines scan-based schemas."""
from inspect import cleandoc

from schema import And, Optional, Or, Schema

from ska_telmodel._common import TMSchema, get_channel_map_schema, mk_if

from .schema import (
    get_scan_channels_schema,
    get_scan_type_schema,
    get_type_name_schema,
)

SCAN_TYPE = "Scan type"


def _add_channel_fields(schema: TMSchema, strict: bool) -> None:
    schema.add_field("count", int, description="Number of channels")
    schema.add_field("start", int, description="First channel ID")
    schema.add_opt_field(
        "stride", int, description="Distance between subsequent channel IDs"
    )
    schema.add_field(
        "freq_min", float, description="Lower bound of first channel"
    )
    schema.add_field(
        "freq_max", float, description="Upper bound of last channel"
    )
    schema.add_opt_field(
        "link_map",
        get_channel_map_schema(int, 0, strict),
        description=cleandoc(
            """
            Channel map that specifies which network link is going to
            get used to send channels to SDP. Intended to allow SDP to
            optimise network and receive node configuration.
            """
        ),
    )


def get_spectral_window(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Spectral window",
        version,
        strict,
        schema={"spectral_window_id": Schema(str)},
    )
    _add_channel_fields(schema, strict)
    return schema


def get_scan_channels_v1(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Scan channels",
        version,
        strict,
        description=cleandoc(
            """
            Informs SDP ingest about the expected channel configuration,
            especially which frequencies are expected to be mapped to
            which channel ID. Note that channel IDs are not guaranteed to be
            continuous, so this might involve gaps and/or strides.
            """
        ),
        as_reference=True,
    )
    _add_channel_fields(schema, strict)
    return schema


def get_scan_channels_v2(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        "Scan channels",
        version,
        strict,
        description="Spectral windows per channel configuration.",
        schema={
            "channels_id": Schema(str),
        },
        as_reference=True,
    )
    schema.add_field(
        "spectral_windows", [get_spectral_window(version, strict)]
    )
    return schema


def get_scan_type_v1(version: str, strict: bool) -> Schema:
    if_strict = mk_if(strict)

    return TMSchema.new(
        SCAN_TYPE,
        version,
        strict,
        schema={
            "id": get_type_name_schema(version, strict, "scan"),
            Optional("coordinate_system"): And("ICRS", if_strict(Or("ICRS"))),
            Optional("ra"): str,
            Optional("dec"): str,
            Optional("channels"): [get_scan_channels_schema(version, strict)],
        },
        as_reference=True,
    )


def get_scan_type_v2(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        SCAN_TYPE,
        version,
        strict,
        as_reference=True,
        description=cleandoc(
            """
            A scan configuration for SDP. Once AssignResources has been
            performed successfully, subsequent Configure commands can
            select from these scan types in order to coordinate SDP
            with other sub-systems participating in the observation -
            for instance to switch between targets, or perform special
            calibration scans.
            """
        ),
    )

    schema.add_field(
        "scan_type_id", get_type_name_schema(version, strict, "scan")
    )
    schema.add_opt_field(
        "reference_frame",
        str,
        check_strict="ICRS",
        description=cleandoc(
            """
            Specification of the reference frame or system for a set
            of pointing coordinates (see ADR-49)
            """
        ),
    )
    schema.add_opt_field(
        "ra", str, description="Right Ascension in degrees (see ADR-49)"
    )
    schema.add_opt_field(
        "dec", str, description="Declination in degrees (see ADR-49)"
    )
    schema.add_opt_field(
        "channels", [get_scan_channels_schema(version, strict)]
    )
    return schema


def get_scan_type_v3(version: str, strict: bool) -> Schema:
    schema = TMSchema.new(
        SCAN_TYPE,
        version,
        strict,
        schema={
            "scan_type_id": get_type_name_schema(version, strict, "scan"),
            Optional("derive_from"): str,
            # More here?
            Optional("beams"): dict,
        },
    )
    return schema


get_scan_channels_schema.register_all(
    ("0.0", "0.1", "0.2", "0.3"), get_scan_channels_v1
)
get_scan_channels_schema.register("0.4", get_scan_channels_v2)
get_scan_type_schema.register_all(("0.0", "0.1", "0.2"), get_scan_type_v1)
get_scan_type_schema.register("0.3", get_scan_type_v2)
get_scan_type_schema.register("0.4", get_scan_type_v3)

"""Miscellaneous schemas that probably should be moved somewhere else."""
from schema import Or, Regex, Schema

#: LOW core receptors, 1-224
LOW_CORE = Regex(r"^C([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-1][0-9]|22[0-4])$")
#: LOW east/north/south receptors.
LOW_DIRS = Regex(r"^[ENS]([1-9]|1[0-6])-[1-6]$")
#: LOW FS 1-512, plus optional substations.
LOW_FS = Regex(
    r"^FS([1-9]|[1-9][0-9]|[1-4][0-9][0-9]|50[0-9]|51[0-2])(\.\S+)?$"
)
#: MID SKA, 001-133.
MID_SKA = Regex(r"^SKA((?!000)0[0-9][0-9]|1[0-2][0-9]|13[0-3])$")
#: MID Meerkat, 000-063.
MID_MKT = Regex(r"^MKT0([0-5][0-9]|6[0-3])$")
#: All receptors.
ALL_RECEPTORS = Or(LOW_CORE, LOW_DIRS, LOW_FS, MID_SKA, MID_MKT)


def get_receptor_schema(strict: bool) -> Schema:
    """
    Return schema for receptors.

    :param strict: check names if set
    :return: schema
    """
    return ALL_RECEPTORS if strict else Schema(str)


def get_beam_function_pattern(strict: bool):
    """Get pattern for SDP beam functions

    As used for SDP configuration - i.e. basically a kind of data
    that the SKA SDP needs to receive.

    :return: A string pattern suitable for use in schemas
    """
    if strict:
        return Or(
            "visibilities",
            "pulsar search",
            "pulsar timing",
            "vlbi",
            "transient buffer",
        )
    else:
        return str

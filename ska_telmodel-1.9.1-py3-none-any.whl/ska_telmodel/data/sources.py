SKA_GITLAB = "gitlab://gitlab.com/ska-telescope"
# Default sources to use.
DEFAULT_SOURCES = [
    f"{SKA_GITLAB}/ska-telmodel-data?main#tmdata",
    f"{SKA_GITLAB}/ska-telmodel?master#tmdata",
    f"{SKA_GITLAB}/mccs/ska-low-mccs?main#tmdata",
]

__all__ = ["DEFAULT_SOURCES"]

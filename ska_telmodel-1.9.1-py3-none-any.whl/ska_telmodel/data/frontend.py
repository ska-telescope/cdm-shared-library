import json
import os
import typing

import yaml

try:
    from yaml import CDumper as Dumper
    from yaml import CLoader as Loader
except ImportError:  # pragma: no cover
    from yaml import Loader, Dumper  # noqa: F401

import pathlib
import urllib.parse
from collections.abc import Iterable

from toolz import itertoolz

from .backend import TELMODEL_BACKENDS, TMDataBackend
from .sources import DEFAULT_SOURCES


class TMData(object):
    """Represents a tree of telescope model data.

    Data is retrieved from specified ``sources`` (or using default
    sources if not passed). Depending on backend, this might cause
    data to be loaded from remote locations, such as the SKAO central
    artefact repository or Gitlab.

    Objects of this class provide a hierarchical
    ``dict``/``h5py``-like interface.  For instance, you can print all
    objects with keys starting with ``instrument/layout`` as follows::

      layouts = tmdata['instrument/layout']
      for key in layouts:
         print(f"Data for {key}: ", layouts[key].get())

    This works because :py:meth:`__getitem__` will redirect to
    :py:meth:`get_subtree` or :py:meth:`get` depending on whether
    a valid key is passed (i.e. it has an extension).
    The :py:class:`TMObject` object can then be used to access
    the underlying telescope model data.

    :param source_uris: List of telescope model data sources.
       If not passed, defaults to ``SKA_TELMODEL_SOURCES``
       enviroment variable, then in-built :py:const:`DEFAULT_SOURCES`.
    :param prefix: Key prefix for sub-tree selection
    :param update: Update cached data sources (if any)
    :param backend_pars: Extra parameters to specific backend (types)

    """

    def __init__(
        self,
        source_uris: list[str] = None,
        prefix: str = "",
        update: bool = False,
        backend_pars: dict = {},
    ):
        if prefix != "" and not TMDataBackend.valid_prefix(prefix):
            raise ValueError(f"Invalid telescope model data prefix: {prefix}")
        self._prefix = prefix

        # Constructing from another Data object?
        if isinstance(source_uris, TMData):
            data = source_uris
            self._source_uris = data._source_uris
            self._sources = data._sources

        else:
            # Default to
            if not source_uris:
                source_uris = os.getenv("SKA_TELMODEL_SOURCES")
                if source_uris:
                    source_uris = source_uris.split(",")
                else:
                    source_uris = DEFAULT_SOURCES

            # Otherwise construct
            self._source_uris = source_uris
            self._sources = []
            for uri in source_uris:
                # Extract backend type
                parsed = urllib.parse.urlparse(uri)

                # Instantiate
                backend_cls = TELMODEL_BACKENDS[parsed.scheme or "file"]
                backend = backend_cls(
                    uri, update, **backend_pars.get(parsed.scheme, {})
                )
                self._sources.append(backend)

    def __iter__(self) -> Iterable[str]:
        # Append '/' to string to remove
        full_prefix = self._prefix
        if full_prefix:
            full_prefix += "/"

        last_key = None
        for key in itertoolz.merge_sorted(
            *(source.list_keys(self._prefix) for source in self._sources)
        ):
            assert key.startswith(full_prefix)

            # De-duplicate
            if last_key is None or key != last_key:
                last_key = key
                yield key[len(full_prefix) :]

    def get_sources(self, pinned: bool = False) -> list[str]:
        """Returns list of source URIs

        :param pinned: Attempt to return URIs that will continue
          to refer to this specific version of telescope model data.
          E.g. for GitLab URIs, this replaces tags or branches by
          the concrete commit hash.
        :returns: list of sources
        """

        return [src.get_uri(pinned) for src in self._sources]

    def get(self, key: str) -> "TMObject":
        """
        Returns the telescope model object with the given key

        :param key: Key to retrive. Must be a valid telescope
          model key (i.e. have a file type extension)
        :returns: :py:class:`TMObject` object
        :raises: ``KeyError`` if object doesn't exist
        """

        # Compose path, check that it is valid
        if self._prefix:
            full_path = self._prefix + "/" + key
        else:
            full_path = key
        if not TMDataBackend.valid_key(full_path):
            raise ValueError(f"Invalid telescope model data key: {full_path}")

        # Find source
        for source in reversed(self._sources):
            # Does it exist?
            entries = list(source.list_keys(full_path))
            if not entries:
                continue
            assert entries == [full_path]

            # Construct
            return TMObject(source, full_path)

        raise KeyError(f"No telescope model data with key {full_path} exists!")

    def get_subtree(self, prefix: str) -> "TMData":
        """
        Returns clone of :py:class:`TMData` object with given prefix

        Note that no checking is done whether any keys with
        the given prefix exist.

        :param prefix: Prefix to narrow scope to.
          Must be a valid telescope model prefix
        :returns: :py:class:`TMData` object using prefix
        """

        # Compose path, check that it is valid
        if self._prefix:
            full_path = self._prefix + "/" + prefix
        else:
            full_path = prefix
        if not TMDataBackend.valid_prefix(full_path):
            raise ValueError(
                f"Invalid telescope model data prefix: {full_path}"
            )

        # Make Data object for subtree. Note that we do *not* check
        # whether the path exists.
        return TMData(self, full_path)

    def __getitem__(self, key_or_prefix: str):
        if not key_or_prefix:
            raise KeyError("Empty key/prefix not allowed!")

        # A key?
        if TMDataBackend.valid_key(key_or_prefix):
            return self.get(key_or_prefix)

        # Otherwise assume we are constructing a subtree
        return self.get_subtree(key_or_prefix)

    def __contains__(self, key: str):
        """
        Check whether a certain key exists in any source.

        :param key: Key to check for
        """

        if self._prefix:
            full_path = self._prefix + "/" + key
        else:
            full_path = key
        for source in self._sources:
            if source.exists(full_path):
                return True
        return False


class TMObject(object):
    """Represents a telescope model data object.
    Provides a number of ways to access the data.

    :param source: Backend to use to retrieve object data
    :param key: Key associated with object
    """

    def __init__(self, source: TMDataBackend, key: str):
        self._source = source
        self._key = key

    def get(self) -> bytes:
        """Access data at given key as raw bytes

        :returns: Raw object data
        """
        return self._source.get(self._key)

    def get_dict(self, **kwargs) -> dict:
        """Access object as a dictionary

        Will only work if the key ends with a known extension --
        e.g. ``.json`` or ``.yaml``.

        :param kwargs: Extra parameters to ``[json/yaml].load``
        :returns: Parsed dictionary
        """

        # Determine type by extension
        ext = pathlib.Path(self._key).suffix
        if ext == ".json":
            with self.open() as f:
                return json.load(f, **kwargs)
        elif ext == ".yaml":
            with self.open() as f:
                return yaml.load(f, Loader=Loader, **kwargs)
        else:
            raise ValueError(f"Cannot deserialise object with suffix {ext}!")

    def open(self) -> typing.IO[bytes]:
        """Access object data as a read-only file object

        :param key: Key to query
        :returns: File-like object
        """
        return self._source.open(self._key)

    def copy(self, dest: str):
        """Copy object data to a file.

        :param dest: Path of destination file
        """

        return self._source.copy(self._key, dest)

"""
SKA Low TMC schemas (beginning)
SKA Mid TMC schemas (bottom)
"""
from inspect import cleandoc

from schema import And, Literal, Schema

from ska_telmodel.csp.schema import get_csp_config_schema
from ska_telmodel.csp.version import CSP_CONFIG_PREFIX
from ska_telmodel.lowcbf.schema import get_vis_descr_outer

# first renamed this file to import
from ska_telmodel.sdp.schema import get_sdp_assignres_schema
from ska_telmodel.sdp.version import SDP_ASSIGNRES_PREFIX

from .._common import TMSchema, mk_if, split_interface_version
from ..mccs import validators as mccs_validators
from .version import (
    LOW_TMC_ASSIGNRESOURCES_PREFIX,
    LOW_TMC_CONFIGURE_PREFIX,
    LOW_TMC_RELEASERESOURCES_PREFIX,
    LOW_TMC_SCAN_PREFIX,
    check_tmc_interface_version,
)


def add_mccs_target_subschema(
    target_schema: TMSchema, version: str, strict: bool
) -> dict:
    """
    Get the mccs.target section of the Configure schema.

    v1.0 and v2.0 Configure schemas differ only in the JSON key names for the
    mccs.target field. This function factors out that difference, allowing the
    rest of the schema, which is identifical between v1 and v2, to be declared
    with a single definition. This function is intended to be called by
    get_tmc_confiure_schema.

    :param version: schema version
    :param strict: strictness level
    :return: dict suitable for insertion in a Schema
    """
    default_keynames = dict(
        reference_frame="reference_frame", target_name="target_name"
    )
    v1_0_keynames = dict(reference_frame="system", target_name="name")

    number = check_tmc_interface_version(version, LOW_TMC_CONFIGURE_PREFIX)
    if number == "1.0":
        keynames = v1_0_keynames
    else:
        keynames = default_keynames

    target_items = TMSchema.new("MCCS target", version=version, strict=strict)
    target_items.add_field(
        keynames["reference_frame"],
        str,
        description=cleandoc(
            """
            Co-ordinate system.

            Must be HORIZON for drift scan.
            """
        ),
    )
    target_items.add_field(
        keynames["reference_frame"],
        str,
        description=cleandoc(
            """
            Co-ordinate system.

            Must be HORIZON for drift scan.
            """
        ),
    )
    target_items.add_field(
        keynames["target_name"], str, description="Name of target."
    )
    target_items.add_field(
        "az", float, description="Pointing azimuth in degrees."
    )
    target_items.add_field(
        "el", float, description="Pointing elevation in degrees."
    )

    target_schema.add_field(
        "target",
        target_items,
        description=cleandoc(
            """
            Target position for the sub-array beam.

            Only drift scan targets are currently implemented by MCCS,
            hence only azimuth and elevation are specified.
            """
        ),
    )


def get_low_tmc_assignresources_schema(version: str, strict: bool) -> Schema:
    """SKA Low Monitoring and Control assign resources schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    if_strict = mk_if(strict)

    items = TMSchema.new("Low TMC assign resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    items.add_field(
        "subarray_id",
        int,
        check_strict=lambda n: mccs_validators.validate_subarray_id(n),
        description="""
            ID of sub-array targeted by this resource allocation request
            """,
    )

    mccs_elems = TMSchema.new("MCCS assign resources", version, strict)
    mccs_elems.add_field(
        "subarray_beam_ids",
        [
            And(
                int,
                if_strict(
                    lambda n: mccs_validators.validate_subarray_beam_id(n)
                ),
            ),
        ],
        check_strict=lambda x: mccs_validators.validate_subarray_beam_ids(x),
        description=cleandoc(
            """
            IDs of the MCCS sub-array beams to allocate to this subarray.

            Each ID must be between 1 and 48, the maximum number of
            sub-array beams.

            As of PI10, only one MCCS sub-array beam can be configured
            per allocation request. Multiple beams must be allocated
            via multiple allocation requests.
            """
        ),
    )
    mccs_elems.add_field(
        "station_ids",
        [
            [
                And(
                    int,
                    if_strict(
                        lambda n: mccs_validators.validate_station_id(n)
                    ),
                )
            ]
        ],
        description=cleandoc(
            """
            IDs of MCCS stations to allocate to this sub-array beam.

            Each ID must be between 1 and 512, the maximum number of
            stations.
            """
        ),
    )
    mccs_elems.add_field(
        "channel_blocks",
        [int],
        check_strict=lambda n: mccs_validators.validate_channel_blocks(n),
        description=cleandoc(
            """
            Number of channel blocks to allocate to this sub-array beam.

            Maximum number of channel blocks = 48.
            """
        ),
    )
    items.add_field(
        "mccs",
        mccs_elems,
        description="MCCS specification for resource allocation.",
    )
    number = check_tmc_interface_version(
        version, LOW_TMC_ASSIGNRESOURCES_PREFIX
    )
    if float(number) >= 3.2:
        sdp_assignres_ver = SDP_ASSIGNRES_PREFIX + "0.4"
        sdpschema = get_sdp_assignres_schema(sdp_assignres_ver, 1)
        items.add_field(
            "sdp",
            sdpschema,
            description="SDP configuration specification",
        )

    return items


def get_all_stn_beams_descr(version: str, strict: bool) -> Schema:
    """Low.CBF station beams description schema"""
    stn_beam_descr = TMSchema.new("Subarray station beams", version, strict)
    stn_beam_descr.add_field("stn_beam_id", int, description="station beam id")
    stn_beam_descr.add_field(
        "freq_ids",
        [
            int,
        ],
        description="list of station beam frequency ids",
    )
    all_stn_beams_descr = TMSchema.new(
        "Subarray stations and station beams", version, strict
    )
    all_stn_beams_descr.add_field(
        "stns",
        [
            [int, int],  # ie [station_id, substation_id],
        ],
        description="",
    )
    all_stn_beams_descr.add_field(
        "stn_beams",
        [
            stn_beam_descr,
        ],
        description="",
    )
    return all_stn_beams_descr


def get_low_tmc_configure_schema(version: str, strict: bool) -> Schema:
    """SKA Low Monitoring and Control configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    if_strict = mk_if(strict)

    items = TMSchema.new("Low TMC configure", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    mccs_items = TMSchema.new("MCCS configure", version, strict)
    mccs_items.add_field(
        "stations",
        [
            {
                Literal(
                    "station_id",
                    description=cleandoc(
                        """
                        MCCS Station ID.

                        Each ID must be between 1 and 512.
                        """
                    ),
                ): And(
                    int,
                    if_strict(
                        lambda n: mccs_validators.validate_station_id(n)
                    ),
                )
            }
        ],
        check_strict=lambda x: mccs_validators.validate_stations(x),
        description=cleandoc(
            """
            IDs of the MCCS stations to configure.

            Maximum array size = 512, the maximum number of MCCS
            stations.
            """
        ),
    )
    mccs_subarray_beams_items = TMSchema.new(
        "MCCS subarray beams", version, strict
    )
    mccs_subarray_beams_items.add_field(
        "subarray_beam_id",
        int,
        check_strict=lambda n: mccs_validators.validate_subarray_beam_id(n),
        description=cleandoc(
            """
            ID of MCCS sub-array beam to configure.

            ID must be an integer between 1 and 48.
            """
        ),
    )
    mccs_subarray_beams_items.add_field(
        "station_ids",
        [
            And(
                int,
                if_strict(lambda n: mccs_validators.validate_station_id(n)),
            ),
        ],
        description=cleandoc(
            """
            IDs of MCCS stations within this sub-array
            beamto configure.

            Array size must be less than 512, the maximum
            number of MCCS stations.

            Each item in the list must be an integer
            between 1 and 512.
            """
        ),
    )
    mccs_subarray_beams_items.add_field(
        "update_rate",
        float,
        check_strict=lambda n: mccs_validators.validate_update_rate(n),
        description=cleandoc(
            """
            Update rate for pointing information.

            Value must be 0.0 or greater.

            TODO: clarify whether this is specified as a
            frequency or as a cadence, plus units.
            """
        ),
    )
    mccs_subarray_beams_items.add_field(
        "channels",
        [And([int], if_strict(lambda n: mccs_validators.validate_channel(n)))],
        check_strict=lambda x: mccs_validators.validate_channels(x),
        description=cleandoc(
            """
            Channel block configurations.

            Each item in the list is a channel block
            configuration, each specified as a list of 4
            numbers as follows:

            [start channel, number of channels, beam index, sub-station index]

            Constraints are:

            0 < start channel < 376

            start channel must be a multiple of 8

            8 < number of channels < 48

            1 < beam index < 48

            1 < sub-station index < 8
            """
        ),
    )
    mccs_subarray_beams_items.add_field(
        "antenna_weights",
        [
            And(
                float,
                if_strict(
                    lambda n: mccs_validators.validate_antenna_weight(n)
                ),
            )
        ],
        check_strict=lambda x: mccs_validators.validate_antenna_weights(x),
        description=cleandoc(
            """
            Antenna weights.

            Maximum array size = 512 (=256 antennas x2 pols per
            sub-array beam).

            Antennas signals can be weighted to modify the station
            beam, varying from 0.0 for full exclusion to potentially
            256.0 for an antenna contribution compensated for the
            number of antennas in the beam. This value is an
            amplitude multiplier added to that antenna signal before
            adding into the sum.

            Weights apply to all channels assigned to a beam.
            """
        ),
    )
    mccs_subarray_beams_items.add_field(
        "phase_centre",
        [
            And(
                float,
                if_strict(
                    lambda n: mccs_validators.validate_phase_centre_value(n)
                ),
            )
        ],
        check_strict=lambda x: mccs_validators.validate_phase_centre(x),
        description=cleandoc(
            """
            Phase centre offset for the station beam, in
            metres.

            The reference position for station phase must be
            modified to reflect antenna weighting and their
            contribution to the station beam. This offset can
            be can considered the desired centre of mass for the
            station.

            Constraints:
            array size = 2
            -20 < phase centre value < 20
            """
        ),
    )

    add_mccs_target_subschema(mccs_subarray_beams_items, version, strict)
    mccs_items.add_field(
        "subarray_beams",
        And(
            [mccs_subarray_beams_items],
            lambda n: len(n) <= mccs_validators.MAX_NO_SUBARRAY_BEAMS,
        ),
        description="MCCS sub-array beam configuration.",
    )
    items.add_field(
        "mccs", mccs_items, description="MCCS configuration specification."
    )
    number = check_tmc_interface_version(version, LOW_TMC_CONFIGURE_PREFIX)
    if float(number) >= 3.1:
        csp_items = TMSchema.new("CSP LOW TMC configure", version, strict)
        csp_items.add_field(
            "interface", str, description="CSP Interface configuration"
        )
        common_item = TMSchema.new(
            "CSP common configuration description", version, strict
        )
        common_item.add_field(
            "config_id", str, description="CSP config id configuration"
        )
        csp_items.add_field(
            "common",
            common_item,
            description="CSP Common configuration specification",
        )
        lowcbf_item = TMSchema.new(
            "LOWCBF subarray configurescan description", version, strict
        )
        lowcbf_item.add_field(
            "stations",
            get_all_stn_beams_descr(version, strict),
            description="Subarray Stations and station beam descriptions",
        )
        lowcbf_item.add_field(
            "vis",
            get_vis_descr_outer(version, strict),
            description="Visibility output descriptions",
        )
        csp_items.add_field(
            "lowcbf",
            lowcbf_item,
            description="LOWCBF configuration specification.",
        )
        items.add_field(
            "csp", csp_items, description="CSP configuration specification."
        ),
        sdp_items = TMSchema.new("SDP LOW TMC configure", version, strict)
        sdp_items.add_field(
            "interface", str, description="SDP Interface configuration"
        )
        sdp_items.add_field(
            "scan_type", str, description="SDP scan type configuration"
        )
        items.add_field(
            "sdp", sdp_items, description="SDP configuration specification."
        )
    items.add_opt_field(
        "tmc",
        {
            Literal(
                "scan_duration",
                description=cleandoc(
                    """
                    Scan duration in seconds.

                    Value must be >= 0.0
                    """
                ),
            ): And(float, if_strict(lambda n: n >= 0.0))
        },
        description="TMC configuration specification.",
    )

    return items


def get_low_tmc_scan_schema(version: str, strict: bool) -> Schema:
    """SKA Low Monitoring and Control scan schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    items = TMSchema.new("Low TMC scan", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    items.add_field(
        "scan_id",
        int,
        description=cleandoc(
            """
            Scan ID to associate with the data.

            The scan ID and SBI ID are used together to uniquely associate
            the data taken with the telescope configuration in effect at
            the moment of observation.
            """
        ),
    )
    number = check_tmc_interface_version(version, LOW_TMC_SCAN_PREFIX)
    if float(number) >= 4.0:
        items.add_field(
            "subarray_id",
            int,
            check_strict=lambda n: mccs_validators.validate_subarray_id(n),
            description="ID of the sub-array which should release resources.",
        )

    return items


def get_low_tmc_releaseresources_schema(version: str, strict: bool) -> Schema:
    """SKA Low Monitoring and Control resources release schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    items = TMSchema.new("Low TMC resource release", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    number = check_tmc_interface_version(
        version, LOW_TMC_RELEASERESOURCES_PREFIX
    )
    if float(number) >= 2.0:
        items.add_opt_field(
            "transaction_id",
            str,
            description="A transaction id specific to the command",
        )
    items.add_field(
        "subarray_id",
        int,
        check_strict=lambda n: mccs_validators.validate_subarray_id(n),
        description="ID of the sub-array which should release resources.",
    )
    items.add_field(
        "release_all",
        bool,
        description=cleandoc(
            """
            true to release all resources, false to release only the
            resources defined in this payload.

            Note: partial resource release for SKA LOW is not implemented
            and the identification of the resources to release is not yet
            part of the schema.
            """
        ),
    )

    return items


def get_tmc_assignedres_schema(version: str, strict: bool) -> Schema:
    """SKA Low Monitoring and Control assigned resources schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    if_strict = mk_if(strict)

    items = TMSchema.new("Low TMC assigned resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )

    mccs_items = TMSchema.new("MCCS assigned resources", version, strict)
    mccs_items.add_field(
        "subarray_beam_ids",
        [
            And(
                int,
                if_strict(
                    lambda n: mccs_validators.validate_subarray_beam_id(n)
                ),
            ),
        ],
        check_strict=lambda x: mccs_validators.validate_subarray_beam_ids(x),
        description=cleandoc(
            """
            IDs of the MCCS sub-array beams allocated to this subarray.

            Each ID must be between 1 and 48, the maximum number of
            sub-array beams.
            """
        ),
    )
    mccs_items.add_field(
        "station_ids",
        [
            [
                And(
                    int,
                    if_strict(
                        lambda n: mccs_validators.validate_station_id(n)
                    ),
                )
            ]
        ],
        description=cleandoc(
            """
            IDs of MCCS stations allocated to each MCCS sub-array beam.

            Each ID must be between 1 and 512, the maximum number of
            stations.
            """
        ),
    )
    mccs_items.add_field(
        "channel_blocks",
        [int],
        check_strict=lambda n: mccs_validators.validate_channel_blocks(n),
        description=cleandoc(
            """
            Number of channel blocks allocated per sub-array beam.

            Maximum number of channel blocks = 48.
            """
        ),
    )
    items.add_field(
        "mccs",
        mccs_items,
        description="""
            Specification of the MCCS resources allocated to this sub-array.
            """,
    )

    return items


"""SKA Mid TMC schemas PI 16 onwards"""


def get_tmc_scan_schema(version: str, strict: bool) -> Schema:
    """
     OET to TMC SubArrayNode.scan schema
    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    items = TMSchema.new("Mid TMC scan", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    items.add_field(
        "scan_id",
        int,
        description="Scan ID to associate with the data.",
    )
    return items


def get_tmc_assignresources_schema(version: str, strict: bool) -> Schema:
    """SKA Mid Monitoring and Control assign resources schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    items = TMSchema.new("Mid TMC assign resources", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    items.add_field(
        "subarray_id",
        int,
        description="""
            ID of sub-array targeted by this resource allocation request
            """,
    )
    # add dish
    dish_elems = TMSchema.new("dish", version, strict)
    dish_elems.add_field(
        "receptor_ids",
        [str],
        description="Receptor ids of dishes",
    )
    items.add_field(
        "dish",
        dish_elems,
        description="Mid Telescope specification for Dish allocation.",
    )
    # add sdp
    assignres_ver = SDP_ASSIGNRES_PREFIX + "0.4"
    sdpschema = get_sdp_assignres_schema(assignres_ver, 1)
    items.add_field(
        "sdp",
        sdpschema,
        description="sdp block for assignres version 0.4",
    )
    return items


"""SKA Mid TMC schemas PI 16 onwards"""

"""
SKA Mid TMC schemas
"""


def get_tmc_configure_schema(version: str, strict: bool) -> Schema:
    """SKA Mid Monitoring and Control configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """

    if_strict = mk_if(strict)
    major, minor = split_interface_version(version)

    items = TMSchema.new("Mid TMC configure", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    pointing_items = TMSchema.new(
        "Pointing Mid TMC configure", version, strict
    )
    target_items = TMSchema.new("Target TMC configure", version, strict)

    target_items.add_opt_field(
        "reference_frame",
        str,
        description="standard celestial reference system such as ICRS",
    )
    target_items.add_opt_field(
        "target_name", str, description="celestial source"
    )
    target_items.add_opt_field(
        "ra", str, description="Pointing Right Ascension coordinates."
    )
    target_items.add_opt_field(
        "dec", str, description="Pointing Declination coordinates."
    )

    if major == 2 and minor >= 2:
        target_items.add_opt_field(
            "ca_offset_arcsec",
            float,
            description=cleandoc(
                """
                Cross-elevation offset in arcseconds from the central
                pointing pointing defined by target's ra+dec.

                This is an optional field; if omitted, an offset of 0
                arcseconds can be assumed.
                """
            ),
        )
        target_items.add_opt_field(
            "ie_offset_arcsec",
            float,
            description=cleandoc(
                """
                Elevation offset in arcseconds from the central pointing
                position defined by the ra+dec pair.

                This is an optional field; if omitted, an offset of 0
                arcseconds can be assumed.
                """
            ),
        )

    pointing_items.add_field(
        "target", target_items, description="Target configuration coordinates"
    )
    items.add_field(
        "pointing",
        pointing_items,
        description="Pointing configuration specification.",
    )
    items.add_opt_field(
        "dish",
        {
            Literal(
                "receiver_band",
                description="Dish Receiver band configuration",
            ): And(str)
        },
        description="Dish band configuration",
    )
    conf_version = CSP_CONFIG_PREFIX + "2.0"
    csp_schema = get_csp_config_schema(conf_version, 1)
    items.add_opt_field(
        "csp",
        csp_schema,
        description="CSP configuration specification.",
    )
    sdp_items = TMSchema.new("SDP Mid TMC configure", version, strict)
    sdp_items.add_field(
        "interface", str, description="SDP Interface configuration"
    )
    sdp_items.add_field(
        "scan_type", str, description="SDP scan type configuration"
    )
    items.add_opt_field(
        "sdp", sdp_items, description="SDP configuration specification."
    )
    tmc_items = TMSchema.new("TMC configure", version, strict)
    tmc_items.add_opt_field(
        "scan_duration",
        And(float, if_strict(lambda n: n >= 0.0)),
        description=cleandoc(
            """
            Scan duration in seconds.

            Value must be >= 0.0
            """
        ),
    )
    if major == 2 and minor > 1:
        tmc_items.add_opt_field(
            "partial_configuration",
            bool,
            description=cleandoc(
                """
                Partial Configuration Flag.

                Partial configurations assume that previously set state is
                maintained, and undergo less strict JSON validation.
                """
            ),
        )
    items.add_opt_field(
        "tmc",
        tmc_items,
        description="TMC Mid TMC configuration specification.",
    )

    return items


def get_tmc_releaseresources_schema(version: str, strict: bool) -> Schema:
    """SKA Mid Monitoring and Control resources release schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: Schema
    """
    items = TMSchema.new("Mid TMC resource release", version, strict)
    items.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    items.add_opt_field(
        "transaction_id",
        str,
        description="A transaction id specific to the command",
    )
    items.add_field(
        "subarray_id",
        int,
        check_strict=lambda n: mccs_validators.validate_subarray_id(n),
        description="ID of the sub-array which should release resources.",
    )
    items.add_field(
        "release_all",
        bool,
        description=cleandoc(
            """
            Scan ID to associate with the data.
            true to release all resources, false to release only the
            resources defined in this payload.

            Note: partial resource release for SKA Mid is not implemented
            and the identification of the resources to release is not yet
            part of the schema.
            """
        ),
    )
    items.add_opt_field(
        "receptor_ids",
        [str],
        description="empty list of receptor_ids when release_all is true",
    )
    return items

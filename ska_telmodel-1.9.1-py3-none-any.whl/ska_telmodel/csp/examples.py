import copy

from .version import (
    CSP_ASSIGNRESOURCES_PREFIX,
    CSP_CONFIG_PREFIX,
    CSP_DELAYMODEL_PREFIX,
    CSP_ENDSCAN_PREFIX,
    CSP_RELEASERESOURCES_PREFIX,
    CSP_SCAN_PREFIX,
    check_csp_interface_version,
)

CSP_CONFIG_1_0 = {
    "interface": "https://schema.skatelescope.org/ska-csp-configure/1.0",
    "subarray": {"subarrayName": "science period 23"},
    "common": {
        "id": "sbi-mvp01-20200325-00001-science_A",
        "frequencyBand": "1",
        "subarrayID": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fspID": 1,
                "functionMode": "CORR",
                "frequencySliceID": 1,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 0,
                "outputLinkMap": [[0, 0], [200, 1]],
            },
            {
                "fspID": 2,
                "functionMode": "CORR",
                "frequencySliceID": 2,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 744,
                "outputLinkMap": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
}

CSP_CONFIG_CAL_A_1_0 = {
    "interface": "https://schema.skatelescope.org/ska-csp-configure/1.0",
    "subarray": {"subarrayName": "science period 23"},
    "common": {
        "id": "sbi-mvp01-20200325-00001-science_A",
        "frequencyBand": "1",
        "subarrayID": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fspID": 1,
                "functionMode": "CORR",
                "frequencySliceID": 1,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 0,
                "outputLinkMap": [[0, 0], [200, 1]],
                "outputHost": [[0, "192.168.1.1"]],
                "outputPort": [[0, 9000, 1]],
            },
            {
                "fspID": 2,
                "functionMode": "CORR",
                "frequencySliceID": 2,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 744,
                "outputLinkMap": [[0, 4], [200, 5]],
                "outputHost": [[0, "192.168.1.1"]],
                "outputPort": [[0, 9744, 1]],
            },
        ],
        "vlbi": {},
    },
}

CSP_CONFIG_SCIENCE_A_1_0 = {
    "interface": "https://schema.skatelescope.org/ska-csp-configure/1.0",
    "subarray": {"subarrayName": "science period 23"},
    "common": {
        "id": "sbi-mvp01-20200325-00001-science_A",
        "frequencyBand": "1",
        "subarrayID": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fspID": 1,
                "functionMode": "CORR",
                "frequencySliceID": 1,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 0,
                "outputLinkMap": [[0, 0], [200, 1]],
                "outputHost": [[0, "192.168.0.1"], [400, "192.168.0.2"]],
                "outputMac": [[0, "06-00-00-00-00-00"]],
                "outputPort": [[0, 9000, 1], [400, 9000, 1]],
            },
            {
                "fspID": 2,
                "functionMode": "CORR",
                "frequencySliceID": 2,
                "integrationTime": 1400,
                "corrBandwidth": 0,
                "channelAveragingMap": [[0, 2], [744, 0]],
                "fspChannelOffset": 744,
                "outputLinkMap": [[0, 4], [200, 5]],
                "outputHost": [[0, "192.168.0.3"], [400, "192.168.0.4"]],
                "outputMac": [[0, "06-00-00-00-00-01"]],
                "outputPort": [[0, 9000, 1], [400, 9000, 1]],
            },
        ],
        "vlbi": {},
    },
}

CSP_CONFIG_0_1 = {
    "id": "sbi-mvp01-20200325-00001-science_A",
    "frequencyBand": "1",
    "fsp": [
        {
            "fspID": 1,
            "functionMode": "CORR",
            "frequencySliceID": 1,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 0,
            "outputLinkMap": [[0, 0], [200, 1]],
        },
        {
            "fspID": 2,
            "functionMode": "CORR",
            "frequencySliceID": 2,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 744,
            "outputLinkMap": [[0, 4], [200, 5]],
        },
    ],
}

CSP_CONFIG_CAL_A_0_1 = {
    "id": "sbi-mvp01-20200325-00001-science_A",
    "frequencyBand": "1",
    "fsp": [
        {
            "fspID": 1,
            "functionMode": "CORR",
            "frequencySliceID": 1,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 0,
            "outputLinkMap": [[0, 0], [200, 1]],
            "outputHost": [[0, "192.168.1.1"]],
            "outputPort": [[0, 9000, 1]],
        },
        {
            "fspID": 2,
            "functionMode": "CORR",
            "frequencySliceID": 2,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 744,
            "outputLinkMap": [[0, 4], [200, 5]],
            "outputHost": [[0, "192.168.1.1"]],
            "outputPort": [[0, 9744, 1]],
        },
    ],
}

CSP_CONFIG_SCIENCE_A_0_1 = {
    "id": "sbi-mvp01-20200325-00001-science_A",
    "frequencyBand": "1",
    "fsp": [
        {
            "fspID": 1,
            "functionMode": "CORR",
            "frequencySliceID": 1,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 0,
            "outputLinkMap": [[0, 0], [200, 1]],
            "outputHost": [[0, "192.168.0.1"], [400, "192.168.0.2"]],
            "outputMac": [[0, "06-00-00-00-00-00"]],
            "outputPort": [[0, 9000, 1], [400, 9000, 1]],
        },
        {
            "fspID": 2,
            "functionMode": "CORR",
            "frequencySliceID": 2,
            "integrationTime": 1400,
            "corrBandwidth": 0,
            "channelAveragingMap": [[0, 2], [744, 0]],
            "fspChannelOffset": 744,
            "outputLinkMap": [[0, 4], [200, 5]],
            "outputHost": [[0, "192.168.0.3"], [400, "192.168.0.4"]],
            "outputMac": [[0, "06-00-00-00-00-01"]],
            "outputPort": [[0, 9000, 1], [400, 9000, 1]],
        },
    ],
}

CSP_CONFIG_2_0 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.0",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {},
}

CSP_CONFIG_CAL_A_2_0 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.0",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
                "output_host": [[0, "192.168.1.1"]],
                "output_port": [[0, 9000, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
                "output_host": [[0, "192.168.1.1"]],
                "output_port": [[0, 9744, 1]],
            },
        ],
        "vlbi": {},
    },
    "pst": {},
}

CSP_CONFIG_SCIENCE_A_2_0 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.0",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
                "output_host": [[0, "192.168.0.1"], [400, "192.168.0.2"]],
                "output_mac": [[0, "06-00-00-00-00-00"]],
                "output_port": [[0, 9000, 1], [400, 9000, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
                "output_host": [[0, "192.168.0.3"], [400, "192.168.0.4"]],
                "output_mac": [[0, "06-00-00-00-00-01"]],
                "output_port": [[0, 9000, 1], [400, 9000, 1]],
            },
        ],
        "vlbi": {},
    },
    "pst": {},
}

CSP_CONFIG_PSS_2_1 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.1",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "PSS-BF",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
            },
        ],
        "search_window": [
            {
                "search_window_id": 0,
                "search_window_tuning": 1000,
                "tdc_enable": True,
            },
        ],
    },
    "pss": {
        "beam_bandwidth": 300,
        "channels_per_beam": 4096,
        "acceleration_search": False,
        "single_pulse_search": True,
        "integration_time": 600,
        "acc_range": 0,
        "number_of_trials": 0,
        "time_resolution": 4,
        "ps_dm": 1000.0,
        "sps_dm": 1000.0,
        "timesample_per_block": 28125000,
        "sub_bands": 64,
        "buffer_size": 18,
        "hsum_control": 16,
        "cxft_control": {},
        "cand_sift": {},
        "cand_output": {},
        "sp_threshold": 10.0,
        "sp_opt_pars": {},
        "dred_beam_stats": {},
        "cdos_control": {},
        "fldo_control": {
            "phase_split": True,
            "channel_scale": True,
            "max_phases": 16,
        },
        "rfim_control": {},
        "beam": [
            {
                "beam_id": 1,
                "reference_frame": "ICRS",
                "ra": 82.7500,
                "dec": 21.0000,
                "centre_frequency": 1400.0,
                "beam_delay_centre": 0.0,
                "dest_host": "192.168.178.25",
                "dest_port": 9021,
            },
            {
                "beam_id": 2,
                "reference_frame": "ICRS",
                "ra": 84.2500,
                "dec": 21.5000,
                "centre_frequency": 1400.0,
                "beam_delay_centre": 0.0,
                "dest_host": "192.168.178.26",
                "dest_port": 9021,
            },
        ],
    },
}

CSP_CONFIG_PST_BEAM_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.2",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "beam": {
            "activation_time": "2022-01-19T23:07:45Z",
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
        },
    },
}

CSP_CONFIG_PST_BEAM_2_3 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "beam": {},
    },
}

CSP_CONFIG_PST_SCAN_PT_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.2",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "beam1",
            "capability": "capability1",
            "scan_id": 1,
            "bits_per_sample": 24,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.81480,
            "observation_mode": "PULSAR_TIMING",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "subarray_id": "subarray42",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 10000.5,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "pt": {
                "dispersion_measure": 100.0,
                "rotation_measure": 0.0,
                "ephemeris": "",
                "pulsar_phase_predictor": "",
                "output_frequency_channels": 1,
                "output_phase_bins": 64,
                "num_sk_config": 1,
                "sk_config": [
                    {
                        "sk_range": [0.8, 0.9],
                        "sk_integration_limit": 100,
                        "sk_excision_limit": 25.0,
                    }
                ],
                "target_snr": 0.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_DS_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.2",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "beam1",
            "capability": "capability1",
            "scan_id": 1,
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "DYNAMIC_SPECTRUM",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "subarray_id": "subarray42",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 13000.2,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "ds": {
                "dispersion_measure": 100.0,
                "output_frequency_channels": 1,
                "stokes_parameters": "Q",
                "num_bits_out": 16,
                "time_decimation_factor": 10,
                "frequency_decimation_factor": 4,
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_FT_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.2",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "beam1",
            "capability": "capability1",
            "scan_id": 1,
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "FLOW_THROUGH",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "subarray_id": "subarray42",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 20000.0,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "ft": {
                "num_bits_out": 32,
                "num_channels": 1,
                "channels": [1],
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_PT_2_3 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.81480,
            "observation_mode": "PULSAR_TIMING",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 10000.5,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "pt": {
                "dispersion_measure": 100.0,
                "rotation_measure": 0.0,
                "ephemeris": "",
                "pulsar_phase_predictor": "",
                "output_frequency_channels": 1,
                "output_phase_bins": 64,
                "num_sk_config": 1,
                "sk_config": [
                    {
                        "sk_range": [0.8, 0.9],
                        "sk_integration_limit": 100,
                        "sk_excision_limit": 25.0,
                    }
                ],
                "target_snr": 0.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_PT_2_4 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
        "eb_id": "eb-m001-20230712-56789",
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "1",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.81480,
            "observation_mode": "PULSAR_TIMING",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 10000.5,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "pt": {
                "dispersion_measure": 100.0,
                "rotation_measure": 0.0,
                "ephemeris": "",
                "pulsar_phase_predictor": "",
                "output_frequency_channels": 1,
                "output_phase_bins": 64,
                "num_sk_config": 1,
                "sk_config": [
                    {
                        "sk_range": [0.8, 0.9],
                        "sk_integration_limit": 100,
                        "sk_excision_limit": 25.0,
                    }
                ],
                "target_snr": 0.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_DS_2_3 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "DYNAMIC_SPECTRUM",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 13000.2,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "ds": {
                "dispersion_measure": 100.0,
                "output_frequency_channels": 1,
                "stokes_parameters": "Q",
                "num_bits_out": 16,
                "time_decimation_factor": 10,
                "frequency_decimation_factor": 4,
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_DS_2_4 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
        "eb_id": "eb-m001-20230712-56789",
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "1",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "DYNAMIC_SPECTRUM",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 13000.2,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "ds": {
                "dispersion_measure": 100.0,
                "output_frequency_channels": 1,
                "stokes_parameters": "Q",
                "num_bits_out": 16,
                "time_decimation_factor": 10,
                "frequency_decimation_factor": 4,
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_FT_2_3 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "FLOW_THROUGH",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 20000.0,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "ft": {
                "num_bits_out": 32,
                "num_channels": 1,
                "channels": [1],
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_FT_2_4 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.4",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
        "eb_id": "eb-m001-20230712-56789",
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "1",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "FLOW_THROUGH",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "CIRC",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 20000.0,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_rfi_frequency_masks": 1,
            "rfi_frequency_masks": [[1.0, 1.1]],
            "destination_address": ["192.168.178.26", 9021],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
            "ft": {
                "num_bits_out": 32,
                "num_channels": 1,
                "channels": [1],
                "requantisation_scale": 1.0,
                "requantisation_length": 1.0,
            },
        },
    },
}

CSP_CONFIG_PST_SCAN_VOLTAGE_RECORDER_2_3 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.3",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "1",
        "subarray_id": 1,
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "VOLTAGE_RECORDER",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "LIN",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 20000.0,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
        },
    },
}


CSP_CONFIG_PST_SCAN_VOLTAGE_RECORDER_2_4 = {
    "interface": "https://schema.skao.int/ska-csp-configure/2.4",
    "subarray": {"subarray_name": "science period 23"},
    "common": {
        "config_id": "sbi-mvp01-20200325-00001-science_A",
        "frequency_band": "low",
        "subarray_id": 1,
        "eb_id": "eb-m001-20230712-56789",
    },
    "cbf": {
        "fsp": [
            {
                "fsp_id": 1,
                "function_mode": "CORR",
                "frequency_slice_id": 1,
                "integration_factor": 1,
                "zoom_factor": 0,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 0,
                "output_link_map": [[0, 0], [200, 1]],
            },
            {
                "fsp_id": 2,
                "function_mode": "CORR",
                "frequency_slice_id": 2,
                "integration_factor": 1,
                "zoom_factor": 1,
                "zoom_window_tuning": 650000,
                "channel_averaging_map": [[0, 2], [744, 0]],
                "channel_offset": 744,
                "output_link_map": [[0, 4], [200, 5]],
            },
        ],
        "vlbi": {},
    },
    "pst": {
        "scan": {
            "activation_time": "2022-01-19T23:07:45Z",
            "timing_beam_id": "1",
            "bits_per_sample": 32,
            "num_of_polarizations": 2,
            "udp_nsamp": 32,
            "wt_nsamp": 32,
            "udp_nchan": 24,
            "num_frequency_channels": 432,
            "centre_frequency": 100000000.0,
            "total_bandwidth": 361689.8148,
            "observation_mode": "VOLTAGE_RECORDER",
            "observer_id": "jdoe",
            "project_id": "project1",
            "pointing_id": "pointing1",
            "source": "J1921+2153",
            "itrf": [5109360.133, 2006852.586, -3238948.127],
            "receiver_id": "receiver3",
            "feed_polarization": "LIN",
            "feed_handedness": 1,
            "feed_angle": 1.234,
            "feed_tracking_mode": "FA",
            "feed_position_angle": 10.0,
            "oversampling_ratio": [8, 7],
            "coordinates": {
                "equinox": 2000.0,
                "ra": "19:21:44.815",
                "dec": "21.884",
            },
            "max_scan_length": 20000.0,
            "subint_duration": 30.0,
            "receptors": ["SKA001", "SKA036"],
            "receptor_weights": [0.4, 0.6],
            "num_channelization_stages": 1,
            "channelization_stages": [
                {
                    "num_filter_taps": 1,
                    "filter_coefficients": [1.0],
                    "num_frequency_channels": 10,
                    "oversampling_ratio": [8, 7],
                }
            ],
        },
    },
}


def get_csp_config_example(version: str, scan: str = None) -> dict:
    """Generate examples for CSP configuration strings

    :param version: Version URI of configuration format
    :param scan: Includes SDP receive addresses for a scan? `None`
       means that this is "template" configuration as passed to
       TMC. Valid parameters: cal_a, science_a
    """

    version_number = check_csp_interface_version(version, CSP_CONFIG_PREFIX)

    if version_number == "0.0" or version_number == "0.1":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_0_1)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_0_1)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_0_1)

    elif version_number == "1.0":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_1_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_1_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_1_0)

    elif version_number == "2.0":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_2_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_2_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_2_0)

    elif version_number == "2.1":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_2_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_2_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_2_0)
        elif scan == "pss":
            return copy.deepcopy(CSP_CONFIG_PSS_2_1)

    elif version_number == "2.2":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_2_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_2_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_2_0)
        elif scan == "pss":
            return copy.deepcopy(CSP_CONFIG_PSS_2_1)
        elif scan == "pst_beam":
            return copy.deepcopy(CSP_CONFIG_PST_BEAM_2_2)
        elif scan == "pst_scan_pt":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_PT_2_2)
        elif scan == "pst_scan_ds":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_DS_2_2)
        elif scan == "pst_scan_ft":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_FT_2_2)

    elif version_number == "2.3":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_2_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_2_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_2_0)
        elif scan == "pss":
            return copy.deepcopy(CSP_CONFIG_PSS_2_1)
        elif scan == "pst_beam":
            return copy.deepcopy(CSP_CONFIG_PST_BEAM_2_3)
        elif scan == "pst_scan_pt":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_PT_2_3)
        elif scan == "pst_scan_ds":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_DS_2_3)
        elif scan == "pst_scan_ft":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_FT_2_3)
        elif scan == "pst_scan_vr":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_VOLTAGE_RECORDER_2_3)

    elif version_number == "2.4":
        if scan is None:
            return copy.deepcopy(CSP_CONFIG_2_0)
        elif scan == "cal_a":
            return copy.deepcopy(CSP_CONFIG_CAL_A_2_0)
        elif scan == "science_a":
            return copy.deepcopy(CSP_CONFIG_SCIENCE_A_2_0)
        elif scan == "pss":
            return copy.deepcopy(CSP_CONFIG_PSS_2_1)
        elif scan == "pst_beam":
            return copy.deepcopy(CSP_CONFIG_PST_BEAM_2_3)
        elif scan == "pst_scan_pt":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_PT_2_4)
        elif scan == "pst_scan_ds":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_DS_2_4)
        elif scan == "pst_scan_ft":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_FT_2_4)
        elif scan == "pst_scan_vr":
            return copy.deepcopy(CSP_CONFIG_PST_SCAN_VOLTAGE_RECORDER_2_4)

    raise ValueError(
        f"Could not generate example for schema {version} scan {scan}!"
    )


CSP_SCAN_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-scan/2.2",
    "scan_id": 7,
}


def get_csp_scan_example(version: str) -> dict:
    """Generate example of CSP scan argument

    :param version: Version URI of configuration format
    """

    version_number = check_csp_interface_version(version, CSP_SCAN_PREFIX)

    if version_number == "2.2":
        scan_example = copy.deepcopy(CSP_SCAN_2_2)
        return scan_example

    raise ValueError(f"Could not generate example for schema {version}!")


CSP_ASSIGNRESOURCES_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-assignresources/2.2",
    "subarray_id": 1,
    "dish": {
        "receptor_ids": [
            "SKA001",
            "SKA036",
        ]
    },
}


def get_csp_assignresources_example(version: str) -> dict:
    """Generate example of CSP assignresources argument

    :param version: Version URI of configuration format
    """

    version_number = check_csp_interface_version(
        version, CSP_ASSIGNRESOURCES_PREFIX
    )

    if version_number == "2.2":
        assignresources_example = copy.deepcopy(CSP_ASSIGNRESOURCES_2_2)
        return assignresources_example

    raise ValueError(f"Could not generate example for schema {version}!")


CSP_ENDSCAN_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-endscan/2.2",
    "scan_id": 15,
}


def get_csp_endscan_example(version: str) -> dict:
    """Generate example of CSP endscan argument

    :param version: Version URI of configuration format
    """

    version_number = check_csp_interface_version(version, CSP_ENDSCAN_PREFIX)

    if version_number == "2.2":
        endscan_example = copy.deepcopy(CSP_ENDSCAN_2_2)
        return endscan_example

    raise ValueError(f"Could not generate example for schema {version}!")


CSP_RELEASERESOURCES_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-releaseresources/2.2",
    "subarray_id": 1,
    "release_all": True,
    "receptor_ids": [
        "SKA001",
        "SKA036",
    ],
}


def get_csp_releaseresources_example(version: str) -> dict:
    """Generate example of CSP releaseresources argument

    :param version: Version URI of configuration format
    """

    version_number = check_csp_interface_version(
        version, CSP_RELEASERESOURCES_PREFIX
    )

    if version_number == "2.2":
        releaseresources_example = copy.deepcopy(CSP_RELEASERESOURCES_2_2)
        return releaseresources_example

    raise ValueError(f"Could not generate example for schema {version}!")


CSP_DELAYMODEL_2_2 = {
    "interface": "https://schema.skao.int/ska-csp-delaymodel/2.2",
    "epoch": 12345678,
    "validity_period": 10.0,
    "delay_details": [
        {
            "receptor": "SKA001",
            "poly_info": [
                {
                    "polarization": "X",
                    "coeffs": [1.01, 1.02, 1.03, 1.04, 1.05, 1.06],
                },
                {
                    "polarization": "Y",
                    "coeffs": [1.1, 1.2, 1.3, 1.4, 1.5, 1.6],
                },
            ],
        },
        {
            "receptor": "SKA100",
            "poly_info": [
                {
                    "polarization": "X",
                    "coeffs": [1.101, 1.102, 1.103, 1.104, 1.105, 1.106],
                },
                {
                    "polarization": "Y",
                    "coeffs": [1.11, 1.12, 1.13, 1.14, 1.15, 1.16],
                },
            ],
        },
    ],
}


def get_csp_delaymodel_example(version: str) -> dict:
    """Generate example of CSP delay model argument

    :param version: Version URI of configuration format
    """

    version_number = check_csp_interface_version(
        version, CSP_DELAYMODEL_PREFIX
    )

    if version_number == "2.2":
        delaymodel_example = copy.deepcopy(CSP_DELAYMODEL_2_2)
        return delaymodel_example

    raise ValueError(f"Could not generate example for schema {version}!")

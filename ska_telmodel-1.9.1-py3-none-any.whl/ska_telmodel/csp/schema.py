"""
Used for checking CSP configuration strings for conformance
"""

from inspect import cleandoc

from schema import And, Optional, Or, Regex, Schema

from .._common import (
    TMSchema,
    get_unique_id_schema,
    mk_if,
    split_interface_version,
)
from . import validators as validators
from . import version as csp_version


def use_camel_case(version: str) -> bool:
    """Checks whether the given CSP schema version uses camel-case
    attribute names.

     :param version: Interface Version URI
     :returns: True or False according to schema version number
    """
    return not (
        version.startswith(csp_version.CSP_CONFIG_VER0)
        or version.startswith(csp_version.CSP_CONFIG_VER1)
    )


def get_vlbi_config_schema(version: str, strict: bool):
    """VLBI specific items

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON schema for the MID.CBF VLBI configuration.
    """

    return TMSchema.new(
        "VLBI config",
        version,
        strict,
        schema={Optional("dummy_param"): str},
        description=cleandoc(
            """
            Very Long Baseline Interferometry specific parameters. To
            be borrowed from IICD This section contains the parameters
            relevant only for VLBI. This section is forwarded only to
            CSP subelement.
            """
        ),
        as_reference=True,
    )


def get_fsp_config_schema(version: str, strict: bool):
    """Frequency slice processor configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON schema for the MID.CBF FSP configuration.
    """

    if_strict = mk_if(strict)
    camel_case = use_camel_case(version)

    elems = TMSchema.new("FSP config", version, strict, as_reference=True)
    elems.add_field(
        ("fsp_id" if camel_case else "fspID"),
        int,
        check_strict=lambda n: n >= 1 and n <= 27,
    )
    elems.add_field(
        ("function_mode" if camel_case else "functionMode"),
        str,
        check_strict=Or("CORR", "PSS-BF", "PST-BF", "VLBI"),
    )
    elems.add_opt_field(
        "receptors",
        [
            Regex(
                r"""^(SKA(00[1-9]|0[1-9][0-9]|1[0-2][0-9]|13[0-3]))|
                (MKT(0[0-5][0-9]|06[0-3]))$"""
            )
            if strict
            else str
        ],
        description=cleandoc(
            """
            Optionally a subset of receptors to be correlated can be
            specified. If not specified, all receptors that belong to
            the subarray are cross-correlated (i.e. visibilities for
            all the baselines in the subarray are generated and
            transmitted to SDP).

            Valid receptor IDs include:
            SKA dishes: "SKAnnn", where nnn is a zero padded integer in the
            range of 001 to 133.
            MeerKAT dishes: "MKTnnn", where nnn is a zero padded integer in the
            range of 000 to 063.
            """
        ),
    )
    elems.add_field(
        ("frequency_slice_id" if camel_case else "frequencySliceID"),
        int,
        check_strict=lambda n: n >= 1 and n <= 26,
        description=cleandoc(
            """
            Frequency Slice to be processed on this FSP (valid range
            depends on the Frequency Band).
            """
        ),
    )
    elems.add_field(
        ("zoom_factor" if camel_case else "corrBandwidth"),
        int,
        check_strict=lambda n: n >= 0 and n <= 6,
        description=cleandoc(
            """
            Bandwidth to be correlated calculated as FSBW/2n, where n is in
            range [0..6].

            When n=0 the full Frequency Slice bandwidth is correlated.

            BW > 0 implies ‘Zoom Window’ configuration; the spectral
            Zoom Window tuning must be specified.
            """
        ),
    )
    elems.add_opt_field(
        ("zoom_window_tuning" if camel_case else "zoomWindowTuning"),
        int,
        description=cleandoc(
            """
            The Zoom Window tuning provided in absolute terms as RF
            center frequency.  Based on that, CSP_Mid calculates
            tuning within the data stream received from the receptor.
            Must be selected so that the entire Zoom Window is within
            the Frequency Slice.  If partially out of the FS a warning
            is generated.  If completely outside of the FS an
            exception is generated.

            Step size <= 0.01MHz.

            The Frequency Band Offset can be used to shift the entire
            observed band in order to accommodate a Zoom Window that
            spans across a Frequency Slice boundary.
            """
        ),
    )
    elems.add_field(
        ("integration_factor" if camel_case else "integrationTime"),
        (
            And(int, if_strict(validators.validate_integration_factor))
            if camel_case
            else 1400
        ),
        description="Integration time for the "
        "correlation products, defines multiple of 140 milliseconds.",
    )
    elems.add_opt_field(
        ("channel_averaging_map" if camel_case else "channelAveragingMap"),
        [And([int], if_strict(lambda lst: len(lst) == 2))],
        description=cleandoc(
            """
            Table of up to 20 x 2 integers. Each of entries contains:

            * Start channel ID, and
            * averaging factor.

            Explanation: Each FSP produces 14880 (TBC) fine channels
            across the correlated bandwidth (Frequency Slice or Zoom
            Window).  Channels are evenly spaced in frequency.

            TM shall provide the table that for each FSP and each
            group of 744 channels (there are 20 groups per FSP)
            indicates the channel averaging factor. More precisely,
            for each group the TMC provided table specifies:

            * the channel ID (integer) of the first channel, and
            * the averaging factor, as follows:

              * 0 means do not send channels to SDP,
              * 1 means no averaging,
              * 2 means average two adjacent channels,
              * 3 means average three adjacent channels,

              and so on.

            If no entry is present for an FSP, the averaging settings
            of the previous FSP are still applicable.
            """
        ),
    )
    elems.add_opt_field(
        ("channel_offset" if camel_case else "fspChannelOffset"),
        int,
        description=cleandoc(
            """
            Channel ID to use for visibilities of the first channel produced
            by this FSP. For example, if the channel offset is 5000 the first
            channel group would span IDs 5000-5743.

            Note that this offset does not apply to channel maps in
            this structure (such as `channelAveragingMap` or
            `outputHost`).
            """
        ),
    )
    elems.add_opt_field(
        ("output_link_map" if camel_case else "outputLinkMap"),
        [And([int, str], if_strict(lambda lst: len(lst) == 2))],
        description=cleandoc(
            """
            Output links to emit visibilities on for every channel, given as a
            list of start channel ID to link ID. Where no value is
            given for concrete channel, the previous value should be
            used.
            """
        ),
    )
    elems.add_opt_field(
        ("output_host" if camel_case else "outputHost"),
        [And([int, str], if_strict(lambda lst: len(lst) == 2))],
        description=cleandoc(
            """
            Output host to send visibilities to for every channel, given as a
            list of start channel ID to host IP addresses in
            dot-decimal notation. Where no value is given for a concrete
            channel, the previous value should be used.
            """
        ),
    )
    elems.add_opt_field(
        ("output_port" if camel_case else "outputPort"),
        [And([int], if_strict(lambda lst: len(lst) >= 2 and len(lst) <= 3))],
        description=cleandoc(
            """
            Output port to send visibilities to for every channel, given as a
            list of start channel ID to port number. Where no value is
            given for a concrete channel, the previous value should be
            used.
            """
        ),
    )
    elems.add_opt_field(
        ("output_mac" if camel_case else "outputMac"),
        [And([int, str], if_strict(lambda lst: len(lst) == 2))],
        description=cleandoc(
            """
            Output MAC address to send visibilities to for every channel,
            given as a list of start channel ID to IEEE 802 MAC
            addresses. Where no value is given for a concrete channel,
            the previous value should be used.
            """
        ),
    )

    return elems


def get_cbf_config_schema(version: str, strict: bool) -> Schema:
    """Correlator and Beamformer configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the MID.CBF configuration.
    """

    # Sub-schemas
    searchWindow = get_search_window_config_schema(version, strict)
    # cbf specific items
    camel_case = use_camel_case(version)

    elems = TMSchema.new(
        "CBF config",
        version,
        strict,
        description=cleandoc(
            """
            Correlator and Beamformer specific parameters. This section
            contains the parameters relevant only for CBF
            sub-element. This section is forwarded only to CBF
            subelement.  Most of it to be borrowed from IICD
            """
        ),
        as_reference=True,
    )
    elems.add_opt_field(
        (
            "frequency_band_offset_stream1"
            if camel_case
            else "frequencyBandOffsetStream1"
        ),
        int,
        description=cleandoc(
            """
            Optionally, an offset can be specified so that the entire observed
            band is shifted (to accommodate a Zoom Window that crosses
            a ‘natural’ Frequency Slice boundary).  If specified,
            applies for all the receptors in the sub-array.

            Bands 1, 2, 3 and 4: input from the receptor consists of a
            single data stream; the Frequency Band Offset (FBO) should
            be specified for Stream 1 only.

            Bands 5a and 5b: input from the receptor consists of two
            data streams; the FBO can be specified for each stream
            independently. Note: For Band 5a and 5b the frequency
            shift is performed by the receptor (DISH).

            Note: This is optional and does not need to be implemented
            in PI3, but would be great for demo; if Team Buttons is
            looking for opportunities to showcase interesting GUIs,
            Zoom Windows are perfect opportunity (would require TMC
            and CSP to support these two parameters, corrBandwidth
            values > 0 and zoom window tuning.)
            """
        ),
    )
    elems.add_opt_field(
        (
            "frequency_band_offset_stream2"
            if camel_case
            else "frequencyBandOffsetStream2"
        ),
        int,
        description="See `frequencyBandOffsetStream1`",
    )
    elems.add_opt_field(
        (
            "delay_model_subscription_point"
            if camel_case
            else "delayModelSubscriptionPoint"
        ),
        str,
        description=cleandoc(
            """
            FQDN of TMC.DelayModel TANGO attribute which exposes
            delay values for all the dishes assigned to a Subarray
            in JSON format. Delay values are updated every 10 seconds.
            """
        ),
    )
    elems.add_opt_field(
        (
            "doppler_phase_corr_subscription_point"
            if camel_case
            else "dopplerPhaseCorrSubscriptionPoint"
        ),
        str,
        description=cleandoc(
            """
            The same model applies for all receptors that belong to
            the subarray.  Delivered by TMC using publish-subscribe
            mechanism (see ICD Section 3.8.8.5.3).  The Doppler phase
            correction, by default, applies only to the CSP_Mid
            Processing Mode Correlation; optionally may apply to other
            Processing Modes as well.
            """
        ),
    )
    elems.add_opt_field(
        ("rfi_flagging_mask" if camel_case else "rfiFlaggingMask"),
        {},
        description=cleandoc(
            """
            Specified as needed in advance of the scan start and/or
            during the scan.  Delivered using publish-subscribe
            mechanism (see ICD Section 3.8.8.5.7).
            """
        ),
    )
    elems.add_field("fsp", [get_fsp_config_schema(version, strict)])
    elems.add_opt_field("vlbi", get_vlbi_config_schema(version, strict))
    elems.add_opt_field("search_window", [searchWindow])

    return elems


def get_search_window_config_schema(version: str, strict: bool) -> Schema:
    """SearchWindow configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the MID.CBF SearchWindow configuration.
    """

    # Search window schema
    camel_case = use_camel_case(version)

    elems = TMSchema.new(
        "Search window config",
        version,
        strict,
        description=cleandoc(
            """
            Up to two 300 MHz Search Windows can be optionally configured and
            used as input for Transient Data Capture and/or Pulsar Search
            beam-forming.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        ("search_window_id" if camel_case else "searchWindowID"),
        int,
        description="Identifier of the 300MHz Search Window. "
        "Unique within a sub-array.",
    )
    elems.add_field(
        ("search_window_tuning" if camel_case else "searchWindowTuning"),
        int,
        description=cleandoc(
            """
            The Search Window tuning is provided in absolute terms as RF
            center frequency. The Search Window must be placed
            within the observed band. If partially out of the
            observed Band a warning is generated. If completely
            outside of the observed Band an exception is
            generated.
            """
        ),
    )
    elems.add_field(
        ("tdc_enable" if camel_case else "tdcEnable"),
        bool,
        description="Enable / disable Transient Data Capture"
        "for the Search Window.",
    )
    elems.add_opt_field(
        ("tdc_num_bits" if camel_case else "tdcNumBits"),
        int,
        description=cleandoc(
            """
            Number of bits per sample (for the Transient Data Capture).
            Required if TDC is enabled, otherwise not specified.
            """
        ),
    )
    elems.add_opt_field(
        ("tdc_period_before_epoch" if camel_case else "tdcPeriodBeforeEpoch"),
        int,
        description=cleandoc(
            """
            Users can trade the period of time for which data are saved and
            transmitted for the sample bit-width and/or the number of
            Search Windows.  The exact information regarding the
            memory capacity per receptor and supported range will be
            provided in construction.

            The epoch is specified in the command that triggers TDC
            off-loading (transmission of data).
            """
        ),
    )
    elems.add_opt_field(
        ("tdc_period_after_epoch" if camel_case else "tdcPeriodAfterEpoch"),
        int,
        description="see `tdcPeriodBeforeEpoch`",
    )
    elems.add_opt_field(
        ("tdc_destination_address" if camel_case else "tdcDestinationAddress"),
        [int, str, str, str],
        description=cleandoc(
            """
            Destination addresses (MAC, IP, port) for off-loading of the
            content of the Transient Data Capture Buffer, specified
            per receptor. The destination addresses for the content of
            the Transient Data Capture can be provided either as a
            part of the scan configuration or by the command that
            triggers transmission of the captured data. The latter, if
            provided, overrides previously set addresses.

            Required if TDC is enabled, otherwise not specified.
            """
        ),
    )

    return elems


def get_subarray_config_schema(version: str, strict: bool) -> Schema:
    """CSP Subarray configuration schema

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the CSP subarray specific configuraiton.
    """

    # # subarray specific items
    camel_case = use_camel_case(version)

    elems = TMSchema.new(
        "subarray",
        version,
        strict,
        description=cleandoc(
            """
            subarray section, containing the parameters relevant only for
            the current sub-array device. This section is not forwarded
            to any subelement.
            """
        ),
    )
    elems.add_field(
        ("subarray_name" if camel_case else "subarrayName"),
        str,
        description=cleandoc(
            """
            Name and scope of current subarray
            the sub-array.
            """
        ),
    )
    return elems


def get_common_config_schema(version: str, strict: bool) -> Schema:
    """CSP Subarray common configuration schema.

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the CSP subarray common
        configuration (ADR-18).
    """

    camel_case = use_camel_case(version)
    (major, minor) = split_interface_version(version)

    # Elements
    elems = TMSchema.new(
        "Common CSP config",
        version,
        strict,
        description=cleandoc(
            """
            Common section, containing the parameters and the sections
            belonging to all CSP sub elements. This section is forwarded to
            all sub-elements.
            """
        ),
        as_reference=True,
    )
    elems.add_opt_field("config_id" if camel_case else "id", str)
    if (major, minor) <= (2, 3):
        elems.add_field(
            ("frequency_band" if camel_case else "frequencyBand"),
            (Regex(r"^(1|2|3|4|5(a|b))$") if strict else str),
            description=cleandoc(
                """
                Frequency band applies for all the receptors (VCCs)
                that belong to the sub-array.
                """
            ),
        )
    else:
        elems.add_field(
            ("frequency_band" if camel_case else "frequencyBand"),
            (Regex(r"^(1|2|3|4|5(a|b)|low)$") if strict else str),
            description=cleandoc(
                """
                Frequency band applies for all the receptors (VCCs)
                that belong to the sub-array.

                The value of 'low' is used to only within SKA Low.
                As this field is a mandatory field but bands 1, 2,
                3, 4, 5a and 5b only make sense for SKA Mid.
                """
            ),
        )

    elems.add_opt_field(
        ("band_5_tuning" if camel_case else "band5Tuning"),
        [float],
        description=cleandoc(
            """
            Center frequency for the Band-of-Interest. Required if Band is 5a
            or 5b; not specified for other Bands (not configurable for
            Band 1, 2, 3 and 4).

            Input for Band 5a and 5b consists of two 2.5 GHz streams;
            the center frequency can be independently tuned for each
            stream.

            The following nomenclature is used to refer to Band 5a and
            5b streams: 5a1, 5a2, 5b1, 5b2.
            """
        ),
    )

    elems.add_opt_field(
        "eb_id",
        get_unique_id_schema(strict, r"eb"),
        description=cleandoc(
            """
            Execution block ID to associate scan configs to an observation.

            This ID is used for associating generated data, especially
            data products, for a given observation.  Multiple scans can
            be linked to one observation and this ID is used as metadata
            to associate the data products from all scans of the same
            observation.

            This ID does not have to be unique for a scan configuration but
            should be unique for different observations.

            For example, all the data and weights files will have an
            EB_ID header value populated with the value supplied in this
            field.
            """
        ),
    )

    # In versions before 1.0, FSPs were part of the common schema
    if version.startswith(csp_version.CSP_CONFIG_VER0):
        elems.add_field("fsp", [get_fsp_config_schema(version, strict)])

    # In version 1.0, subarrayID was added
    elif version.startswith(csp_version.CSP_CONFIG_VER1):
        elems.add_field("subarrayID", int, description="Subarray number")
        # And(int, if_strict(lambda n: n >= 1 and n <= 17)),

    # In version 2.0, subarray_id was added
    else:
        elems.add_field("subarray_id", int, description="Subarray number")
        # And(int, if_strict(lambda n: n >= 1 and n <= 17)),

    # all subelements common schema
    return elems


def get_pss_config_schema(version: str, strict: bool) -> Schema:
    """Pulsar Search specific items

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PSS configuration.
    """

    major, minor = split_interface_version(version)

    elems = TMSchema.new(
        "PSS configuration", version, strict, as_reference=True
    )
    if (major, minor) < (2, 1):
        elems.add_opt_field("dummy_param", str)

    else:
        elems.add_field(
            "beam_bandwidth",
            int,
            check_strict=lambda n: n <= 300,
            description="Beam bandwidth (MHz)",
        )
        elems.add_field(
            "channels_per_beam",
            int,
            check_strict=lambda n: n >= 1000 and n <= 4096,
            description="Number of channels per beam",
        )
        elems.add_field(
            "acceleration_search",
            bool,
            description=cleandoc(
                """
                Processing Mode: Acceleration Search (a.k.a.
                Pulsar Search) and Single Pulse Search (a.k.a.
                Transient Search) can be performed
                concurrently.
                """
            ),
        )
        elems.add_field(
            "single_pulse_search",
            bool,
            description=cleandoc(
                """
                Processing Mode: Acceleration Search (a.k.a.
                Pulsar Search) and Single Pulse Search (a.k.a.
                Transient Search) can be performed
                concurrently.
                """
            ),
        )
        elems.add_field(
            "integration_time",
            int,
            check_strict=lambda n: n > 0 and n <= 1800,
            description="Scan duration.",
        )
        elems.add_opt_field(
            "acc_range",
            int,
            check_strict=lambda n: n >= 0 and n <= 350,
            description="Range in source acceleration to be searched.",
        )
        elems.add_field(
            "number_of_trials",
            int,
            check_strict=lambda n: n >= 0,
            description="Number of trials to be performed.",
        )
        elems.add_field(
            "time_resolution",
            int,
            check_strict=lambda n: n >= 0 and ((2 * n + 1) * 64) <= 800,
            description="Time resolution of input data.",
        )
        elems.add_field(
            "ps_dm",
            float,
            check_strict=lambda n: n > 0.0 and n <= 3000.0,
            description="Dispersion corretion for acceleration search.",
        )
        elems.add_field(
            "sps_dm",
            float,
            check_strict=lambda n: n > 0.0 and n <= 3000.0,
            description="Dispersion corretion for transient search.",
        )
        elems.add_field(
            "timesample_per_block",
            int,
            description="Number of time samples in each block of data.",
        )
        elems.add_field(
            "sub_bands",
            int,
            check_strict=lambda n: n > 0 and n <= 64,
            description=cleandoc(
                """
                Number of frequency band groups summed
                up during folding.
                """
            ),
        )
        elems.add_field(
            "buffer_size",
            int,
            check_strict=lambda n: n >= 18 and n <= 24,
            description=cleandoc(
                """
                Size of the buffer receiving raw data.
                (2**buffer_size)
                """
            ),
        )
        elems.add_field(
            "hsum_control",
            int,
            check_strict=lambda n: n >= 1 and n <= 32,
            description=cleandoc(
                """
                Number of the “harmonic folds” on the initial
                Fourier power-spectrum summed up.
                """
            ),
        )
        elems.add_field(
            "cxft_control", dict, description="CXFT control parameters."
        )
        elems.add_field(
            "cand_sift",
            dict,
            description="Constraints on matches between candidates.",
        )
        elems.add_field(
            "cand_output",
            dict,
            description="Define data sinks and subscriber to be notified.",
        )
        elems.add_field(
            "sp_threshold",
            float,
            description=cleandoc(
                """
                Threshold for a single pulse trigger.
                (Tuned to system noise and RFI env.)
                """
            ),
        )
        elems.add_field(
            "sp_opt_pars",
            dict,
            description="Single pulse optimization parameters.",
        )
        elems.add_field(
            "dred_beam_stats",
            dict,
            description=cleandoc(
                """
                DRED: statistics of spectra to derive the
                normalization factors.
                """
            ),
        )
        elems.add_field(
            "cdos_control",
            dict,
            description=cleandoc(
                """
                CDOS: control parameters and related
                statistical data.
                """
            ),
        )
        elems.add_field(
            "rfim_control", dict, description="RFIM control parameters."
        )
        elems.add_field(
            "fldo_control",
            {"phase_split": bool, "channel_scale": bool, "max_phases": int},
            description="FLDO control parameters.",
        )
        elems.add_field("beam", [get_pss_beam_config_schema(version, strict)])

    return elems


def get_pss_beam_config_schema(version: str, strict: bool) -> Schema:
    """Pulsar Search Beam specific items

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PSS beam configuration.
    """

    elems = TMSchema.new("PSS beam config", version, strict, as_reference=True)
    elems.add_field(
        "beam_id",
        int,
        check_strict=lambda n: n >= 1 and n <= 1500,
        description="Search Beam ID.",
    )
    elems.add_opt_field(
        "ra",
        float,
        description="Right Ascension of sub-array beam target, in degrees.",
    )
    elems.add_opt_field(
        "dec",
        float,
        description="Declination of sub-array beam target, in degrees.",
    )
    elems.add_opt_field(
        "reference_frame",
        str,
        check_strict=Or("ICRS", "HORIZON"),
        description="reference frame for pointing coordinates",
    )
    elems.add_field(
        "centre_frequency",
        float,
        description="Centre frequency of the search beam.",
    )
    elems.add_field(
        "beam_delay_centre",
        Or(float, str),
        description="Beam delay center, relative to the array delay center.",
    )
    elems.add_opt_field(
        "dest_host",
        str,
        description="Per beam destination host address for PSS output.",
    )
    elems.add_opt_field(
        "dest_port",
        int,
        description="Per beam destination port for PSS output.",
    )

    return elems


def get_pst_config_schema(version: str, strict: bool) -> Schema:
    """Pulsar Timing specific items

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PST configuration.
    """

    major, minor = split_interface_version(version)

    elems = TMSchema.new(
        "PST configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters. To be borrowed from IICD
            This section contains the parameters relevant only for
            PST. This section is forwarded only to PST subelement.
            """
        ),
        as_reference=True,
    )

    if (major, minor) < (2, 2):
        elems.add_opt_field("dummy_param", str)
    else:
        elems.add_opt_field(
            "scan", get_pst_scan_config_schema(version, strict)
        )
        elems.add_opt_field(
            "beam", get_pst_beam_config_schema(version, strict)
        )

    return elems


def get_pst_beam_config_schema(version: str, strict: bool) -> Schema:
    """Pulsar Timing specific beam configuration

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PST beam configuration.
    """

    major, minor = split_interface_version(version)

    elems = TMSchema.new(
        "PST beam configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific beam configuration parameters.
            This section contains the parameters relevant only for
            PST. This section is forwarded only to PST subelement.

            As of version 2.3 this schema has no elements and is
            deprecated
            """
        ),
        as_reference=True,
    )
    if (major, minor) < (2, 3):
        elems.add_field(
            "activation_time",
            str,
            description=cleandoc(
                """
                Date and time when to start the PST reconfiguration in UTC.

                **Keyword:** ACTIVATION_TIME
                """
            ),
        )
        elems.add_field(
            "num_channelization_stages",
            int,
            check_strict=lambda n: n >= 1 and n <= 2,
            description=cleandoc(
                """
                The number of stages used to channelize the data: e.g.
                * for Low, there are 2 stages: 1 in LFAA and 1 in CBF
                * for Mid, there are 2 stages: 1 in FSP and 1 in PST BF.

                **Keyword:** NSTAGE
                """
            ),
        )
        elems.add_field(
            "channelization_stages",
            [_get_pst_channelisation_schema(version, strict)],
            description="List of configuration for each channelization stage.",
        )

    return elems


def _get_pst_channelisation_schema(version: str, strict: bool) -> Schema:
    """Pulsar Timing specific configuration for a channelisation stage.

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PST channelisation stage.
    """

    elems = TMSchema.new(
        "PST channelization stage configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters for channelization
            stage configuration.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "num_filter_taps",
        int,
        check_strict=lambda n: n >= 1 and n <= 2**32,
        description=cleandoc(
            """
            Total number of taps in the prototype filter (i.e. over
            all arms) used in the stage.

            **Keyword:** NSTAP_k
            """
        ),
    )
    elems.add_field(
        "filter_coefficients",
        [float],
        description=cleandoc(
            """
            An array of filter coefficients that define the (time
            domain) response function of the prototype filter used
            in the stage.

            Length of this is num_filter_taps.

            **Keyword:** COEFF_k
            """
        ),
    )
    elems.add_field(
        "num_frequency_channels",
        int,
        check_strict=lambda n: n >= 1 and n <= 2**32,
        description=cleandoc(
            """
            The number of frequency channels output by each polyphase
            filter bank (PFB) for this stage.

            **Keyword:** NCHAN_PFB_k
            """
        ),
    )
    elems.add_field(
        "oversampling_ratio",
        [int],
        check_strict=lambda x: len(x) == 2,
        description=cleandoc(
            """
            The oversampling ratio expressed as a fraction as an array
            of int, with the first value the numerator and the second is
            the denominator. (e.g. 8/7 is assigned as [8,7]).

            **Keyword:** OVERSAMP_k
            """
        ),
    )

    return elems


def get_pst_scan_config_schema(version: str, strict: bool) -> Schema:
    """Pulsar Timing specific scan configuration

    :param version: Interface Version URI
    :param strict: Schema strictness
    :return: the JSON Schema for the PST scan configuration.
    """

    if_strict = mk_if(strict)

    (major, minor) = split_interface_version(version)

    elems = TMSchema.new(
        "PST scan configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific scan configuration parameters.
            This section contains the parameters relevant only for
            PST. This section is forwarded only to PST subelement.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "activation_time",
        str,
        description=cleandoc(
            """
            Date and time when to start the PST reconfiguration.

            **Units:** UTC timestamp
            **Keyword:** ACTIVATION_TIME
            """
        ),
    )
    if (major, minor) < (2, 3):
        elems.add_field(
            "timing_beam_id",
            str,
            description=cleandoc(
                """
                Identifier assigned by LMC/TM used to identify the beam
                configuraiton.

                PST selects which PST server to use for this scan and timing
                beam, and provides a mapping from the timing beam identifier
                by the TM to PST capability id.

                **Keyword:** BEAM
                """
            ),
        )
        elems.add_field(
            "capability",
            str,
            description=cleandoc(
                """
                Identifier of the capability PST Beam to be used for this
                configuration.

                **Keyword:** CAPABILITY
                """
            ),
        )
        elems.add_field(
            "scan_id",
            int,
            description=cleandoc(
                """
                The identifier for the scan to be configured.

                This is a 64bits long.

                **Keyword:** SCAN_ID
                """
            ),
        )
        elems.add_field(
            "subarray_id",
            str,
            description=cleandoc(
                """
                The ID for the sub-array.

                **Keyword:** SUBARRAY_ID
                """
            ),
        )

    elems.add_opt_field(
        "timing_beam_id",
        str,
        description=cleandoc(
            """
            Identifier assigned by LMC/TM used to identify the beam
            configuraiton.

            PST selects which PST server to use for this scan and timing
            beam, and provides a mapping from the timing beam identifier
            by the TM to PST capability id.

            **Keyword:** BEAM
            """
        ),
    )
    elems.add_field(
        "bits_per_sample",
        int,
        check_strict=lambda n: n in [16, 24, 32],
        description=cleandoc(
            """
            The number of bits per complex-values time sample in the CBF
            output data.

            Valid values are 16, 24, or 32.

            **Keyword:** NBIT
            """
        ),
    )
    elems.add_field(
        "num_of_polarizations",
        int,
        check_strict=lambda n: n in [1, 2],
        description=cleandoc(
            """
            The number of polarizations in the CBF output data.

            Valid values are 1 or 2.

            **Keyword:** NPOL
            """
        ),
        default=2,
    )
    elems.add_field(
        "udp_nsamp",
        int,
        check_strict=lambda n: n in [4, 32],
        description=cleandoc(
            """
            The number of time samples for each single polarization
            and the a single frequency in each UDP packet sent by CBF.

            Note: this must be an integer multiple of WT_NSMAP

            **Range:** 4 (Low), 32 (Mid)
            **Keyword:** UDP_NSAMP
            """
        ),
    )
    elems.add_field(
        "wt_nsamp",
        int,
        check_strict=lambda n: n in [4, 32],
        description=cleandoc(
            """
            The number of time samples described by as single relative
            weight. There is a unique relative weight for each frequency
            channel, and each relative weight describes both polarizations.

            **Range:** 4 (Low), 32 (Mid)
            **Keyword:** WT_NSAMP
            """
        ),
    )
    elems.add_field(
        "udp_nchan",
        int,
        check_strict=lambda n: n in [24, 185],
        description=cleandoc(
            """
            The number of contiguous frequency channels in each UDP packet
            sent by CBF.

            **Range:** 24 (Low), 185 (Mid)
            **Keyword:** UDP_NCHAN
            """
        ),
    )
    elems.add_field(
        "num_frequency_channels",
        int,
        check_strict=lambda n: n >= 1 and n <= 82944,
        description=cleandoc(
            """
            The total number of frequency channels into which the total
            critical bandwidth has been divided.

            This must be an integer multiple of udp_nchan

            **Range:** 1 to 82944
            **Keyword:** OBSNCHAN
            """
        ),
    )
    elems.add_field(
        "centre_frequency",
        float,
        check_strict=lambda x: x >= 50e6 and x <= 12800e6,
        description=cleandoc(
            """
            Centre frequency of to the total (critical) bandwidth spanned by
            the frequency channels.

            **Units:** Hz
            **Range:** 50e6 to 12800e6
            **Keyword:** OBSFREQ
            """
        ),
    )
    elems.add_field(
        "total_bandwidth",
        float,
        check_strict=lambda x: x >= 3610 and x <= 2.5e9,
        description=cleandoc(
            """
            Total (critical) bandwidth spanned by the channels of the
            observation.

            Low: 0.00361 to 300 MHz

            Mid: 0.053.76 to 2500 MHz

            **Units:** Hz
            **Range:** 3610 to 2.5e9
            **Keyword:** OBSBW
            """
        ),
    )
    if (major, minor) < (2, 3):
        elems.add_field(
            "observation_mode",
            str,
            check_strict=Or(
                "PULSAR_TIMING", "DYNAMIC_SPECTRUM", "FLOW_THROUGH"
            ),
            description=cleandoc(
                """
                The observation mode used for the scan.

                **Range:** PULSAR_TIMING, DYNAMIC_SPECTRUM, or FLOW_THROUGH
                **Keyword:** OBSMODE
                """
            ),
        )
    else:
        elems.add_field(
            "observation_mode",
            str,
            check_strict=Or(
                "PULSAR_TIMING",
                "DYNAMIC_SPECTRUM",
                "FLOW_THROUGH",
                "VOLTAGE_RECORDER",
            ),
            description=cleandoc(
                """
                The observation mode used for the scan.

                The value VOLTAGE_RECORDER is added for AA0.5, while the other
                values will be needed for in the future for data processing.

                **Keyword:** OBSMODE
                """
            ),
        )

    elems.add_field(
        "observer_id",
        str,
        description=cleandoc(
            """
            The observer in charge of the observations.

            **Keyword:** OBSERVER
            """
        ),
    )
    elems.add_field(
        "project_id",
        str,
        description=cleandoc(
            """
            The project that the observations are for.

            **Keyword:** PROJID
            """
        ),
    )
    elems.add_field(
        "pointing_id",
        str,
        description=cleandoc(
            """
            The ID for the sub-array pointing.

            **Keyword:** PNT_ID
            """
        ),
    )
    elems.add_field(
        "source",
        str,
        description=cleandoc(
            """
            The name of the source.

            **Keyword:** SRC_NAME
            """
        ),
    )
    elems.add_field(
        "itrf",
        [float],
        check_strict=lambda x: len(x) == 3,
        description=cleandoc(
            """
            The International Terrestrial Reference Frame (ITRF) coordinates
            of the telescope delay centre.

            **Units:** metres
            **Keyword:** ITRF
            """
        ),
    )
    elems.add_field(
        "receiver_id",
        str,
        description=cleandoc(
            """
            The receiver name or ID (instrument).

            **Keyword:** FRONTEND
            """
        ),
    )
    elems.add_field(
        "feed_polarization",
        str,
        check_strict=Or("LIN", "CIRC"),
        description=cleandoc(
            """
            The native polarization of feed.

            **Range:** LIN or CIRC
            **Keyword:** FD_POLN
            """
        ),
        default="LIN",
    )
    elems.add_field(
        "feed_handedness",
        int,
        check_strict=Or(-1, 1),
        description=cleandoc(
            """
            Code for sense of feed.

            For value of +1 for XYZ forming RH set with Z in the
            direction of propagation. Looking up into the feed of a
            prime-focus receiver or at the sky).

            For FD_HAND = +1, the rotation from A (or X) to B (or Y)
            is counter clockwise or in the direction of increasing
            Feed Angle (FA) or Position Angle (PA).

            For circular feeds, FD_HAND = +1 for IEEE LCP on the A (or
            X) probe.

            **Range:** -1 or +1
            **Keyword:** FD_HAND
            """
        ),
    )
    elems.add_field(
        "feed_angle",
        float,
        check_strict=lambda x: x >= -180 and x <= 180,
        description=cleandoc(
            """
            Feed angle of the E-vector for an equal in-phase response from the
            A(X) and B(Y) probes, measured in the direction of
            increasing feed angle or position angle (clockwise when
            looking down on a prime focuse receiver).

            **Units:** degrees
            **Range:** -180 to 180.
            **Keyword:** FD_SANG
            """
        ),
    )
    elems.add_field(
        "feed_tracking_mode",
        str,
        check_strict=Or("FA", "CPA", "SPA", "TPA"),
        description=cleandoc(
            """
            The tracking mode for the feed:

            * **FA** - constant feed angle and that the feed stays
              fixed with respect to the telescope's reference frame.
            * **CPA** - the feed rotates to maintain a constant phase
              angle (i.e.  it tracks the variation of the parallactic
              angle.). When the cordinate mode is GALATIC, PA is with
              respect to Galactic north and similarly for coordinate
              mode ECLIPTIC then PA is with respect to ecliptic north.
            * **SPA** - the feed angle is held fixed at an angle such
              that the requested PA is obtained at the mid-point of
              the observation.
            * **TPA** - is only relevant for scan observations - the
              feed is rotated to maintain a constant angle with
              respect to the scan direction.

            **Range:** FA, CPA, SPA, or TPA
            **Keyword:** FD_MODE
            """
        ),
    )
    elems.add_field(
        "feed_position_angle",
        float,
        check_strict=lambda x: x >= -180 and x <= 180,
        description=cleandoc(
            """
            The requested angle of feed reference.

            For feed_mode = 'FA' this is respect to the telescope's reference
            frame (feed_angle = 0), and for feed_mode = 'CPA' this is with
            respect to the celestial north (parallic angle = 0) or with respect
            to the Galactic north for coordinate_mode = 'GALACTIC'.

            **Range:** -180 to +180.

            **Keyword:** FA_REQ
            """
        ),
    )
    elems.add_field(
        "oversampling_ratio",
        [int],
        check_strict=lambda x: len(x) == 2,
        description=cleandoc(
            """
            The oversampling ratio expressed as a fraction as an array
            of int, with the first value the numerator and the second is
            the denominator. (e.g. 8/7 is assigned as [8,7]).

            **Range:** 8/7 or 4/3
            **Keyword:** OVERSAMP
            """
        ),
    )
    elems.add_field(
        "coordinates",
        _get_pst_equitorial_coordinates(version, strict),
        description=cleandoc(
            """
            The tied-array beam's tracking co-ordinates.

            As of version 2.2 of the schema this only handles
            equitorial tracking which means uses RA/Dec J2000.0 coords
            but PST may support different tracking modes and
            coordinates the future.
            """
        ),
    )
    elems.add_field(
        "max_scan_length",
        float,
        check_strict=lambda n: n >= 30 and n <= 43200,
        description=cleandoc(
            """
            The maximum length of the observation.

            **Units:** seconds
            **Range:** 30 - 43200
            **Keyword:** SCANLEN_MAX
            """
        ),
    )
    elems.add_field(
        "subint_duration",
        float,
        check_strict=lambda n: n >= 1 and n <= 60,
        description=cleandoc(
            """
            The length of each output sub-integration.

            **Units:** seconds
            **Range:** 1 - 60
            **Keyword:** OUTSUBINT
            """
        ),
    )
    elems.add_field(
        "receptors",
        [str],
        check_strict=lambda x: len(x) >= 1 and len(x) <= 512,
        description=cleandoc(
            """
            An array of receptor IDs for the receptors included in the
            sub-array.

            **Keyword:** ANTENNA
            """
        ),
    )
    elems.add_field(
        "receptor_weights",
        [float],
        description=cleandoc(
            """
            Weight for each receptor.

            **Range:** 0 - 1.0
            **Keyword:** ANT_WEIGHTS
            """
        ),
    )
    elems.add_opt_field(
        "num_rfi_frequency_masks",
        int,
        check_strict=lambda n: n >= 0 and n <= 1024,
        description=cleandoc(
            """
            The number of frequency ranges to be masked.

            **Range:** 0 - 1024
            **Keyword:** NMASK
            """
        ),
        default=0,
    )
    elems.add_opt_field(
        "rfi_frequency_masks",
        [And([float], if_strict(lambda x: len(x) == 2))],
        description=cleandoc(
            """
            A two-dimensional array of length of num_frequency_mask of known
            RFI frequency ranges to excise from the data.

            The array contains mask pairs of [f_min, f_max] pairs for known
            frequency ranges containing RFI not excised by the CBF.

            The overall dimension of this array is num_frequency_mask x 2.

            **Units:** Hz
            **Keyword:** FREQ_MASK
            """
        ),
    )

    if (major, minor) < (2, 3):
        # calibration is not supported. If needed in future this needs logic
        # that if cal_mod is not "OFF" then the other fields are required.
        elems.add_opt_field(
            "cal_mode",
            And(str, Or("OFF", "SYNC", "EXT1", "EXT2")),
            description=cleandoc(
                """
                Operation mode for the injected calibration:

                * OFF: there is no injected calibration.
                * SYNC: the calibration is pulsed synchronously with the
                  folding frequency.
                * EXT1/EXT2: the calibration is driven by one of two
                  possible user defined external signals.

                **Range:** [OFF, SYNC, EXT1, EXT2]
                **Keyword:** CAL_MODE
                """
            ),
        )
        elems.add_opt_field(
            "calibration_modulation_frequency",
            float,
            check_strict=lambda x: x >= 0.001 and x <= 1000.0,
            description=cleandoc(
                """
                The modulation frequency for the injected calibration signal.

                **Range:** 0.001 - 1000
                **Units:** Hertz
                **Keyword:** CAL_FREQ
                """
            ),
        )
        elems.add_opt_field(
            "calibration_duty_cycle",
            float,
            check_strict=lambda x: x >= 0.0 and x <= 1.0,
            description=cleandoc(
                """
                Duty cycle for the injected calibration signal.

                **Range:** 0.0 - 1.0
                **Keyword:** CAL_DCYC
                """
            ),
        )
        elems.add_opt_field(
            "calibration_phase",
            float,
            check_strict=lambda x: x >= 0.0 and x <= 1.0,
            description=cleandoc(
                """
                The calibration phase with respect to time.

                Phase of the leasing edge of the injected calibration signal
                in calibration SYNC mode.

                **Range:** 0.0 - 1.0
                **Keyword:** CAL_PHS
                """
            ),
        )
        elems.add_opt_field(
            "calibration_num_phase_states",
            float,
            description=cleandoc(
                """
                The number of pulses in one period of the calibration phase.

                **Keyword:** CAL_NPHS
                """
            ),
        )

    elems.add_opt_field(
        "destination_address",
        [
            str,
            int,
        ],
        description=cleandoc(
            """
            The destination address for the PST output data.

            Includes IPv4 Address, port number.
            """
        ),
    )
    elems.add_opt_field(
        "test_vector_id",
        str,
        description=cleandoc(
            """
            Identifier for a test vectore that will be present in the
            tied-array beam data stream beam CBF and PST.

            **Keyword:** TEST_VECTOR
            """
        ),
    )
    elems.add_opt_field("pt", _get_pst_pt_mode_schema(version, strict))
    elems.add_opt_field("ds", _get_pst_ds_mode_schema(version, strict))
    elems.add_opt_field("ft", _get_pst_ft_mode_schema(version, strict))

    if (major, minor) >= (2, 3):
        elems.add_field(
            "num_channelization_stages",
            int,
            check_strict=lambda n: n >= 1 and n <= 2,
            description=cleandoc(
                """
                The number of stages used to channelize the data: e.g.
                * for Low, there are 2 stages: 1 in LFAA and 1 in CBF
                * for Mid, there are 2 stages: 1 in FSP and 1 in PST BF.

                **Keyword:** NSTAGE
                """
            ),
        )
        elems.add_field(
            "channelization_stages",
            [_get_pst_channelisation_schema(version, strict)],
            description="List of configuration for each channelization stage.",
        )

    return elems


def _get_pst_pt_mode_schema(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify a PST mode configuration for the
    'PULSAR_TIMING' observing mode.

    :param version: Interface version
    :param strict: Schema strictness
    :return: The JSON Schema for the PST 'PULSAR_TIMING' mode configuration.
    """

    elems = TMSchema.new(
        "PST 'PULSAR_TIMING' mode configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters for the 'PULSAR_TIMING' mode
            configuration.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "dispersion_measure",
        float,
        check_strict=lambda n: n >= 0 and n <= 100000,
        description=cleandoc(
            """
            The dispersion measure for coherent/inchoerent de-dispersion.

            **Units:** pccm^-3
            **Range:** 0 - 100000
            **Keyword:** DM
            """
        ),
    )
    elems.add_opt_field(
        "rotation_measure",
        float,
        check_strict=lambda n: n >= -2e9 and n <= 2e9,
        description=cleandoc(
            """
            The rotation measure for phase-coherent Faraday rotation
            correction.

            **Units:** radians per metre squared
            **Keyword:** RM
            """
        ),
    )
    elems.add_field(
        "ephemeris",
        str,
        description=cleandoc(
            """
            The ephemeris of the pulsar being observed.

            **Units:** PSRCAT compatible ASCII string
            **Keyword:** EPHEMERIS
            """
        ),
    )
    elems.add_field(
        "pulsar_phase_predictor",
        str,
        description=cleandoc(
            """
            Pulsar phase predictor generated from ephemeris.

            **Units:** TEMPO2 compatible ASCII string
            **Keyword:** PREDICTOR
            """
        ),
    )
    elems.add_field(
        "output_frequency_channels",
        int,
        description=cleandoc(
            """
            The number of output frequency channels. This must
            be between 1 and the number of observation channels.

            **Keyword:** OUTNCHAN
            """
        ),
    )
    elems.add_field(
        "output_phase_bins",
        int,
        check_strict=lambda n: n >= 64 and n <= 2048,
        description=cleandoc(
            """
            The number of output phase bins.

            **Range:** 64 - 2048
            **Keyword:** OUTNBIN
            """
        ),
    )
    elems.add_field(
        "num_sk_config",
        int,
        description=cleandoc(
            """
            The number of spectral kurtosis (SK) configurations to apply.

            **Keyword:** N_SK
            """
        ),
    )
    elems.add_field(
        "sk_config",
        [_get_pst_sk_config_schema(version, strict)],
        description="List of spectral kurtosis configurations.",
    )
    elems.add_field(
        "target_snr",
        float,
        description=cleandoc(
            """
            The signal-to-noise ratio (SNR) of the on-pulse flux for
            the scan. May be used to prematurely end a scan when the
            integrated SNR reaches the target. A value of 0 indicates
            there is no limit.

            **Keyword:** TARGET_SNR
            """
        ),
    )

    return elems


def _get_pst_sk_config_schema(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify a a spectral kurtosis (SK) configuration
    used in the 'PULSAR_TIMING' mode.

    :param version: Interface version
    :param strict: Schema strictness
    :return: The JSON Schema for the PST spectural kurtosis configuration.
    """

    elems = TMSchema.new(
        "PST spectral kurtosis configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters for the spectral kurtosis (SK)
            for the 'PULSAR_TIMING' mode.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "sk_range",
        [float],
        check_strict=lambda x: len(x) == 2,
        description=cleandoc(
            """
            Frequency ranges for each spectral kurtosis (SK) configuration.

            **Units:** Hz
            **Keyword:** SK_RNG
            """
        ),
    )
    elems.add_field(
        "sk_integration_limit",
        int,
        check_strict=lambda n: n >= 64 and n <= 1024,
        description=cleandoc(
            """
            The number of input time samples integrated into each spectral
            kurtosis (SK) statistic.

            **Range:** 64 - 1024
            **Keyword:** SK_INTS
            """
        ),
    )
    elems.add_field(
        "sk_excision_limit",
        float,
        check_strict=lambda n: n >= 1.0 and n <= 100.0,
        description=cleandoc(
            """
            Spectral kurtosis excision limits (RFI threshold) in
            units of standard deviations.

            **Range:** 1 - 100
            **Keyword:** SK_EXIS
            """
        ),
    )

    return elems


def _get_pst_ds_mode_schema(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify a PST 'DYNAMIC_SPECTRUM' mode configuration.

    :param version: Interface version
    :param strict: Schema strictness
    :return: The JSON Schema for the PST 'DYNAMIC_SPECTRUM' mode configuration.
    """

    elems = TMSchema.new(
        "PST 'DYNAMIC_SPECTRUM' mode configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters for the 'DYNAMIC_SPECTRUM' mode
            configuration.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "dispersion_measure",
        float,
        check_strict=lambda n: n >= 0 and n <= 100000,
        description=cleandoc(
            """
            The dispersion measture for coherent/inchoerent de-dispersion.

            This is only required for pulsar timing and dynamic spectrum modes.

            **Range:** [0, 100000]
            **Keyword:** DM
            """
        ),
    )
    elems.add_opt_field(
        "rotation_measure",
        float,
        check_strict=lambda n: n >= -2e9 and n <= 2e9,
        description=cleandoc(
            """
            The rotation measure for phase-coherent Faraday rotation
            correction.

            **Units:** radians per metre squared
            **Keyword:** RM
            """
        ),
    )
    elems.add_field(
        "output_frequency_channels",
        int,
        description=cleandoc(
            """
            The number of output frequency channels. This must
            be between 1 and the number of observation channels.

            **Keyword:** OUTNCHAN
            """
        ),
    )
    elems.add_field(
        "stokes_parameters",
        str,
        description=cleandoc(
            """
            The Stokes parameters to output when in Dynamic
            spectrum mode.

            **Range:** string with a combination of I, Q, U, and V.
            **Keyword:** STOKES_FB
            """
        ),
    )
    elems.add_field(
        "num_bits_out",
        int,
        check_strict=Or(1, 2, 4, 8, 16, 32),
        description=cleandoc(
            """
            The number of bits per output sample.

            **Range:** 1, 2, 4, 8, 16 or 32
            **Keyword:** NBIT_OUT
            """
        ),
    )
    elems.add_field(
        "time_decimation_factor",
        int,
        description=cleandoc(
            """
            The number of input samples per output time sample
            when in Dynamic Spectrum mode.

            **Keyword:** TDEC_FB
            """
        ),
    )
    elems.add_field(
        "frequency_decimation_factor",
        int,
        description=cleandoc(
            """
            The number of input frequency channels incoherently
            added to each output frequency channel in Dynamic
            Spectrum.

            This is required in addition to output_frequency_channels
            because some frequency channels may be merged coherently
            to increase temporal resolution.

            **Keyword:** FDEC_FB
            """
        ),
    )
    elems.add_opt_field(
        "num_sk_config",
        int,
        description=cleandoc(
            """
            The number of spectral kurtosis (SK) configurations to apply.

            **Keyword:** N_SK
            """
        ),
    )
    elems.add_opt_field(
        "sk_config",
        [_get_pst_sk_config_schema(version, strict)],
        description="List of spectral kurtosis configurations.",
    )
    elems.add_field(
        "requantisation_scale",
        float,
        description=cleandoc(
            """
            Scale factor to govern the dynamic range for fixed precision
            output to be applied during re-quantisation.

            **Keyword:** DIGITIZER_SCALE
            """
        ),
    )
    elems.add_field(
        "requantisation_length",
        float,
        description=cleandoc(
            """
            Length of data to be used when determining the scaling factors
            used for fixed precision output during re-quantisation.

            **Units:** seconds
            **Keyword:** DIGITIZER_LENGTH
            """
        ),
    )

    return elems


def _get_pst_ft_mode_schema(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify a PST 'FLOW_THROUGH' mode configuration.

    :param version: Interface version
    :param strict: Schema strictness
    :return: The JSON Schema for the PST 'FLOW_THROUGH' mode configuration.
    """

    elems = TMSchema.new(
        "PST 'FLOW_THROUGH' mode configuration",
        version,
        strict,
        description=cleandoc(
            """
            Pulsar Timing specific parameters for the 'FLOW_THROUGH' mode
            configuration.
            """
        ),
        as_reference=True,
    )
    elems.add_field(
        "num_bits_out",
        int,
        check_strict=Or(1, 2, 4, 8, 16, 32),
        description=cleandoc(
            """
            The number of bits per output sample.

            **Range:** 1, 2, 4, 8, 16 or 32
            **Keyword:** NBIT_OUT
            """
        ),
    )
    elems.add_field(
        "num_channels",
        int,
        description=cleandoc(
            """
            The number of input channels to be recorded.
            This value must be less than or equal to the
            output_frequency_channels.

            **Keyword:** NCHAN_FT
            """
        ),
    )
    elems.add_field(
        "channels",
        [int],
        description=cleandoc(
            """
            An array of indexes of frequency channels to be recorded.
            Length of this array should be num_channels.

            **Keyword:** CHAN_FT
            """
        ),
    )
    elems.add_field(
        "requantisation_scale",
        float,
        description=cleandoc(
            """
            Scale factor to govern the dynamic range for fixed precision
            output to be applied during re-quantisation.

            **Keyword:** DIGITIZER_SCALE
            """
        ),
    )
    elems.add_field(
        "requantisation_length",
        float,
        description=cleandoc(
            """
            Length of data to be used when determining the scaling factors
            used for fixed precision output during re-quantisation.

            **Units:** seconds
            **Keyword:** DIGITIZER_LENGTH
            """
        ),
    )

    return elems


def _get_pst_equitorial_coordinates(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify RA/Dec coordinates used within PST.

    As of version 2.2 of the schema this only handles RA/Dec J2000 coords
    but PST may support different tracking modes and coordinates the
    future.

    :param version: Interface version
    :param strict: Schema strictness
    :return: The JSON Schema
    """

    elems = TMSchema.new(
        "PST RA/Dec coordinates",
        version,
        strict,
        description="""
           Pulsar Timing specific parameters for RA/Dec tracking coordinates.
           """,
        as_reference=True,
    )
    elems.add_opt_field(
        "equinox",
        float,
        check_strict=lambda x: x >= 2000,
        description=cleandoc(
            """
            The coordinate epoch.

            This can be in Julian date or Modified Julian Date.

            **Units:** years
            **Range:** >= 2000
            **Keyword:** EQUINOX
            """
        ),
        default=2000.0,
    )
    elems.add_field(
        "ra",
        str,
        description=cleandoc(
            """
            The Right Accession (RA) of the coordinates used for tracking.

            Valid formats is 'hh:mm:ss.sss' or 'ddd.ddd'

            **Keyword:** STT_CTD1
            """
        ),
    )
    elems.add_field(
        "dec",
        str,
        description=cleandoc(
            """
            The declination (Dec) of the coordinates used for tracking.

            Valid formats is 'hh:mm:ss.sss' or 'ddd.ddd'

            **Keyword:** STT_CTD2
            """
        ),
    )

    return elems


def get_csp_config_schema(version: str, strict: bool) -> Schema:
    """
    Returns a schema to verify a CSP configuration

    :param version: Interface version
    :param strict: Strict mode - refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the CSP configuration.
    :raise: `ValueError` exception on mismatch major version or invalid JSON
            Schema URI
    """

    # Convert version to standard format
    version = csp_version.normalize_csp_config_version(version)

    # Valid?
    csp_version.check_csp_interface_version(
        version, csp_version.CSP_CONFIG_PREFIX
    )

    # Pre-ADR-18 version with everything in the top level?
    elems = TMSchema.new("CSP config", version, strict)
    if version.startswith(csp_version.CSP_CONFIG_VER0):
        # Overall configuration schema
        elems.update(get_common_config_schema(version, strict))
        return elems

    elif version.startswith(csp_version.CSP_CONFIG_VER1):
        # Overall configuration schema
        elems.add_opt_field("interface", str)
        elems.add_field(
            "subarray", get_subarray_config_schema(version, strict)
        )
        elems.add_field("common", get_common_config_schema(version, strict))
        elems.add_field("cbf", get_cbf_config_schema(version, strict))
        elems.add_opt_field("pss", get_pss_config_schema(version, strict))
        elems.add_opt_field("pst", get_pst_config_schema(version, strict))
        return elems

    elif version.startswith(csp_version.CSP_CONFIG_VER2):
        # Overall configuration schema
        elems.add_field("interface", str)
        elems.add_field(
            "subarray", get_subarray_config_schema(version, strict)
        )
        elems.add_field("common", get_common_config_schema(version, strict))
        elems.add_field("cbf", get_cbf_config_schema(version, strict))
        elems.add_opt_field("pss", get_pss_config_schema(version, strict))
        elems.add_opt_field("pst", get_pst_config_schema(version, strict))
        return elems

    else:
        major_version, _ = split_interface_version(version)
        raise ValueError(f"Unknown major schema version: {major_version}")


def get_csp_scan_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema to verify the CSP scan command.

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    scan_schema = TMSchema.new("CSP scan", version, strict)
    scan_schema.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    scan_schema.add_field(
        "scan_id",
        int,
        description="Scan ID to associate with the data.",
    )

    return scan_schema


def get_csp_assignresources_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema to verify the CSP assignresources command.

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    assignresources_schema = TMSchema.new(
        "CSP assignresources", version, strict
    )
    assignresources_schema.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    assignresources_schema.add_field(
        "subarray_id",
        int,
        description=cleandoc(
            """
            The Subarray ID that the list of receptors will be assigned to.
            For Mid, there are a maximum of 16 subarrays.
            """
        ),
    )

    dish_elements = TMSchema.new("dish assignresources", version, strict)
    dish_elements.add_field(
        "receptor_ids",
        [
            Regex(
                r"""^(SKA(00[1-9]|0[1-9][0-9]|1[0-2][0-9]|13[0-3]))|
                (MKT(0[0-5][0-9]|06[0-3]))$"""
            )
            if strict
            else str
        ],
        description=cleandoc(
            """
            The list of receptors that will be assigned to the Subarray ID.
            Receptor IDs can be any string, not necessarily numbers.

            Valid receptor IDs include:
            SKA dishes: "SKAnnn", where nnn is a zero padded integer in the
            range of 001 to 133.
            MeerKAT dishes: "MKTnnn", where nnn is a zero padded integer in the
            range of 000 to 063.
            """
        ),
    )
    assignresources_schema.add_field(
        "dish",
        dish_elements,
    )

    return assignresources_schema


def get_csp_endscan_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema to verify the CSP endscan command.

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    endscan_schema = TMSchema.new("CSP endscan", version, strict)
    endscan_schema.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    endscan_schema.add_field(
        "scan_id",
        int,
        description="Scan ID to end.",
    )

    return endscan_schema


def get_csp_releaseresources_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema to verify the CSP releaseresources command.

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    releaseresources_schema = TMSchema.new(
        "CSP releaseresources", version, strict
    )
    releaseresources_schema.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    releaseresources_schema.add_field(
        "subarray_id",
        int,
        description="Subarray ID which will have its resource(s) released.",
    )
    releaseresources_schema.add_opt_field(
        "release_all",
        bool,
        description=cleandoc(
            """
            Set to true if you wish to release all resources assigned to the
            Subarray.
            """
        ),
    )
    releaseresources_schema.add_opt_field(
        "receptor_ids",
        [
            Regex(
                r"""^(SKA(00[1-9]|0[1-9][0-9]|1[0-2][0-9]|13[0-3]))|
                (MKT(0[0-5][0-9]|06[0-3]))$"""
            )
            if strict
            else str
        ],
        description=cleandoc(
            """
            The list of receptors that will be released from the Subarray ID.
            Receptor IDs can be any string, not necessarily numbers.

            Valid receptor IDs include:
            SKA dishes: "SKAnnn", where nnn is a zero padded integer in the
            range of 001 to 133.
            MeerKAT dishes: "MKTnnn", where nnn is a zero padded integer in the
            range of 000 to 063.
            """
        ),
    )

    return releaseresources_schema


def get_csp_delaymodel_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema to verify the CSP delaymodel command.

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    delaymodel_schema = TMSchema.new(
        "CSP delaymodel",
        version,
        strict,
    )
    delaymodel_schema.add_field(
        "interface",
        str,
        description="URI of JSON schema applicable to this JSON payload.",
    )
    delaymodel_schema.add_field(
        "epoch",
        int,
        description=cleandoc(
            """
            Time when delay model becomes valid
            (when Mid.CBF shall apply the new model) specified as
            32bit UTC time code containing a count of the number of
            integer seconds since the January 1, 1970, 00h:00m:00s epoch.

            Range: 32-bit number
            """
        ),
    )
    delaymodel_schema.add_field(
        "validity_period",
        float,
        description=cleandoc(
            """
            validity period of the delay model (starting at epoch) [s]

            Range: positive number
            """
        ),
    )
    delaymodel_schema.add_field(
        "delay_details",
        [get_csp_delay_details_schema(version, strict)],
    )

    return delaymodel_schema


def get_csp_delay_details_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema with the CSP delay details

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    delaydetails_schema = TMSchema.new(
        "delay details",
        version,
        strict,
        as_reference=True,
    )
    delaydetails_schema.add_field(
        "receptor",
        (
            Regex(
                r"""^(SKA(00[1-9]|0[1-9][0-9]|1[0-2][0-9]|13[0-3]))|
                (MKT(0[0-5][0-9]|06[0-3]))$"""
            )
            if strict
            else str
        ),
        description=cleandoc(
            """
            ICD DISH to CSP defines DISH ID as 16 bit field.
            The receptorID specified in the delay model should be the same
            as the one inserted in the data stream received from the receptor.

            Valid receptor IDs include:
            SKA dishes: "SKAnnn", where nnn is a zero padded integer in the
            range of 001 to 133.
            MeerKAT dishes: "MKTnnn", where nnn is a zero padded integer in the
            range of 000 to 063.

            Range: any string
            """
        ),
    )
    delaydetails_schema.add_field(
        "poly_info",
        [get_csp_poly_info_schema(version, strict)],
    )

    return delaydetails_schema


def get_csp_poly_info_schema(version: str, strict: bool) -> Schema:
    """
    Returns the schema with the CSP delay details

    :param version: Interface version URI
    :param strict: Strict mode. If true, refuse even harmless schema
       violations (like extra keys). DO NOT USE FOR INPUT VALIDATION!
    :return: The JSON Schema for the command.
    :raise: `ValueError` exception on invalid JSON Schema URI.
    """

    polyinfo_schema = TMSchema.new(
        "poly info",
        version,
        strict,
        as_reference=True,
    )
    polyinfo_schema.add_field(
        "polarization",
        str,
        description=cleandoc(
            """
            Polarization of the delay model entry

            Range: X or Y
            """
        ),
    )
    polyinfo_schema.add_field(
        "coeffs",
        [float],
        description=cleandoc(
            """
            Delay Model is specified as coefficients
            for a 5th order polynomial.
            Coefficients of the polynomial are specified as an array.
            The delay at time t, where t is measured with respect the
            beginning of the validity interval is calculated as:

            d(t) = c0 + c1*t + c2*t^2 + c3*t^3 + c4*t^4 + c5*t^5

            Units for coefficients c0,c1,..c5:
            ns/s^k where k=0,1,..5

            Range for coefficients: 64 bit number
            """
        ),
    )

    return polyinfo_schema

"""
csp.validators module defines constants and functions for
validating CSP fields in schemas.
"""

MAX_NO_INTEGRATION_FACTOR = 10


def validate_integration_factor(integration_factor: int) -> bool:
    """Checks if the integration_factor is valid.

    :param integration_factor: Integration time for correlation products
    :returns: True if integration_factor is valid
    """
    return 1 <= integration_factor <= MAX_NO_INTEGRATION_FACTOR

"""
  created file to maintain televalidation constant
"""
MID_VALIDATION_CONSTANT_JSON_FILE_PATH = (
    "instrument/ska1_mid/validation/mid-validation-constants.json"
)
LOW_VALIDATION_CONSTANT_JSON_FILE_PATH = (
    "instrument/ska1_low/validation/low-validation-constants.json"
)
MID_LAYOUT_CONSTANT_JSON_FILE_PATH = (
    "instrument/ska1_mid/layout/mid-layout.json"
)
LOW_LAYOUT_CONSTANT_JSON_FILE_PATH = (
    "instrument/ska1_low/layout/low-layout.json"
)

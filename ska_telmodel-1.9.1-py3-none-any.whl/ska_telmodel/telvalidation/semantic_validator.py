"""
This module contains the functions which is exposed to outside for use
"""
import logging

from ska_telmodel.data import TMData

from .constant import (
    LOW_VALIDATION_CONSTANT_JSON_FILE_PATH,
    MID_VALIDATION_CONSTANT_JSON_FILE_PATH,
)
from .oet_tmc_validators import validate_json
from .schematic_validation_exceptions import SchematicValidationError

logging.getLogger("telvalidation")


def validate_command_input(config: dict, tm_data: TMData, interface: str):

    if "low" in interface:
        semantic_validate_data = tm_data[
            LOW_VALIDATION_CONSTANT_JSON_FILE_PATH
        ].get_dict()
    else:
        semantic_validate_data = tm_data[
            MID_VALIDATION_CONSTANT_JSON_FILE_PATH
        ].get_dict()

    msg_list = validate_json(
        semantic_validate_data["AA0.5"],
        command_input_json_config=config,
        error_msg_list=[],
        parent_key=None,
    )

    return msg_list


def semantic_validate(
    config: dict,
    tm_data: TMData,
    interface: str = None,
    raise_semantic: bool = True,
):
    """

    :param config: dictionary containing details of the command
        which needs validation.
        This is same as for ska_telmodel.schema.validate.
        If command available as json string
        first convert to dictionary by json.loads.
    :param tm_data: telemodel tm data object using which
            we can load semantic validate json.
    :param interface: interface uri in full only provide if missing in config
    :param raise_semantic: True(default) would need user
        to catch somewhere the SchematicValidationError.
        Set False to only log the error messages.
    :returns: msg: if semantic validation fail returns error message containing
        all combined error which arises else returns True.
    """
    # fetching interface value from config
    version = config.get("interface")
    if version is None:
        version = interface
    # if still version remain null
    if version is None:
        message = """interface is missing from config.
        Please provide interface='...' explicitly"""
        logging.warning(message)
        raise SchematicValidationError(message)
    msg = ""
    msg_list = validate_command_input(config, tm_data, version)
    msg_list = [k for k in msg_list if k is not None]
    msg = ",".join(msg_list) if msg_list else msg
    # add in the list the specific substrings
    # which when appear in message indicate no error
    # success_keys=["Success!","Is visible?Yes","1","2"]
    if msg is not None and msg != "":
        logging.error(
            """Also following errors were encountered
              during semantic validations:\n"""
            + msg
        )
        if raise_semantic is True:
            raise SchematicValidationError(msg)
    return True
